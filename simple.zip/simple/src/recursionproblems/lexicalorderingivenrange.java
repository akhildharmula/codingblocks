package recursionproblems;

public class lexicalorderingivenrange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=20;
		logic(n,0);

	}

	private static void logic(int n, int ans) {
		// TODO Auto-generated method stub
		if(ans>n)
		{
			return;
		}
		System.out.println(ans);
		if(ans==0)
		{
			for(int i=1;i<=9;i++)
			{
				logic(n,ans*10+i);
			}
		}
		else
		{
			for(int i=0;i<=9;i++)
			{
				logic(n,ans*10+i);
			}
		}
		
	}

}
