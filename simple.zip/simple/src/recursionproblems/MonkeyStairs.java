package recursionproblems;

public class MonkeyStairs {
   // static int count=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5;
		int k=NumberOfWays(n,"");
		System.out.println("Total Number of Paths :"+ k);

	}

	private static int NumberOfWays(int n, String ans) {
		// TODO Auto-generated method stub
		if(n==0)
		{
			System.out.println(ans);
			//count++;
			return 1;
		}
		if(n<0)return 0;
		
		int a=NumberOfWays(n-1,ans+1);
		int b=NumberOfWays(n-2,ans+2);
		int c=NumberOfWays(n-3,ans+3);
		return a+b+c;
	}

}
