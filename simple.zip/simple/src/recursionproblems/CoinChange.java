package recursionproblems;

public class CoinChange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {2,1,5,10,20};
		System.out.println("Total count: "+print(arr,17,""));
	}

	private static int print(int[] arr, int target, String ans) {
		// TODO Auto-generated method stub
		if(target==0)
		{
			System.out.println(ans);
			return 1;
		}
		if(target<0)
		{
			return 0;
		}
		int count=0;
		for(int i=0;i<arr.length;i++)
		{
			count+=print(arr,target-arr[i],ans+arr[i]);
		}
		return count;
		
	}

}
