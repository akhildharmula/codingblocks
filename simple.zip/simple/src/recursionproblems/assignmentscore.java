package recursionproblems;
import java.util.*;
public class assignmentscore {
	public static int print(int arr[],int score,int sum,int idx,int currsum)
    {
        if(currsum==sum-currsum)
        {
            int first[] =new int[arr.length];
            int second[]=new int[arr.length];
            score++;
            int c=0;
            for(int i=0;i<idx;i++)
            {
                    first[c]=arr[i];
                    c++;
            }
            first=Arrays.copyOf(first,c);
            c=0;
            for(int i=idx;i<arr.length;i++)
            {
                    second[c]=arr[i];
                    c++;
            }
            second=Arrays.copyOf(second,c);
            System.out.println("fisrt"+Arrays.toString(first));
            System.out.println("second"+Arrays.toString(second));
            if(currsum!=0)
            {
              int score1=print(first,score,currsum,0,0);
            int score2=print(second,score,sum-currsum,0,0);
            return Math.max(score1,score2);
            }
            else
            {
                return Math.max(first.length-1,second.length-1)+score;
            }
        }
        if(currsum>sum-currsum)
        {
            return score;
        }
         if(idx==arr.length)
        {
            return score;
        }
         score=print(arr,score,sum,idx+1,currsum+arr[idx]);
      
      return score;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
           int n=sc.nextInt();
           int arr[]=new int[n];
           int sum=0;
           for(int i=0;i<n;i++)
           {
               arr[i]=sc.nextInt();
               sum+=arr[i];
           }
           if(sum==0)
           {
        	   System.out.println(arr.length-1);
        	   return;
           }
           int score=0;
           score=print(arr,score,sum,0,0);
           System.out.println(score);
           sc.close();
	}

}
