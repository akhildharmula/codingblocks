package recursionproblems;

public class firstOccurenceofele {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = { 1, 2, 3, 4, 5, 3 };
		int ele = 3;
		// System.out.println(firstoccurrence(a,ele,0));
		// System.out.println(lastoccurrence(a,ele,a.length-1));
		int b[]=Alloccurencee(a, ele, 0,0);
		for(int k : b)
		{
			System.out.println(k);
		}
		

	}

	private static int[] Alloccurencee(int[] a, int ele, int i,int count) {
		// TODO Auto-generated method stub
		if(i==a.length)
		{
			return new int[count];
		}
		if(a[i]==ele)
		{
			count++;
		}
		int [] ans=Alloccurencee(a,ele,i+1,count);
		if(a[i]==ele)
		{
			ans[count-1]=i;
		}
		return ans;
	}

	private static int firstoccurrence(int[] a, int ele, int i) {
		// TODO Auto-generated method stub
		if (i < a.length) {
			if (ele == a[i]) {
				return i;
			}
			return (firstoccurrence(a, ele, i + 1));
		}
		return -1;
	}

	private static int lastoccurrence(int[] a, int ele, int i) {
		// TODO Auto-generated method stub
		if (i >= 0) {
			if (ele == a[i]) {
				return i;
			}
			return (lastoccurrence(a, ele, i--));
		}
		return -1;
	}

}
