package inheritence;

public class c extends p{
	int d=2;
	int dc=20;
	
	public void fun()
	{
		System.out.println("Fun inside child Class");
	}
	
	public void funchild()
	{
		System.out.println("Funchild inside child Class");
	}

}
