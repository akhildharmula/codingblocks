package simple;

import java.util.*;

public class BostonNumbers {
	public static int isprime(int n) {
		if (n < 2) {
			return 0;
		}
		if (n == 2 || n == 3) {
			return 1;
		}
		if (n % 2 == 0 || n % 3 == 0) {
			return 0;
		}
		for (int i = 5; i < Math.sqrt(n); i = i + 6) {
			if (n % i == 0 || n % (i + 2) == 0) {
				return 0;
			}
		}
		return 1;
	}

	public static int sumofdigits(int n) {
		int sum = 0;
		while (n != 0) {
			sum = sum + n % 10;
			n = n / 10;
		}
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number");
		int n = sc.nextInt();
		sc.close();
		int digitssum = sumofdigits(n);
		int sumprimefactors = 0;
		int fact = 2;
		while (n > 1) {
			if (n % fact == 0) {
				if (isprime(fact) == 1) {

					int sum = sumofdigits(fact);
					sumprimefactors = sumprimefactors + sum;

					n = n / fact;
				}
			} else {
				fact++;
			}
		}
		if (sumprimefactors == digitssum) {
			System.out.println("It is Bostan Number(1)");
		} else {
			System.out.println("It Not a Bostan Number(0)");
		}
	}

}
