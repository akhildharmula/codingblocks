package simple;

import java.util.*;

public class OnlyPrimeMultiplesOfNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number");
		int n = sc.nextInt();
		sc.close();
		ArrayList<Integer> list=new ArrayList<>();
		int fact=2;
		while(n>1)
		{
			if(n%fact==0)
			{
				if(isprime(fact)==1)
				{
					list.add(fact);
					n=n/fact;
				}
			}
			else
			{
				fact++;
			}
		}
		System.out.println(list);

	}

	private static int isprime(int n) {
		// TODO Auto-generated method stub
		if (n < 2) {
			return 0;
		}
		if (n == 2 || n == 3) {
			return 1;
		}
		if (n % 2 == 0 || n % 3 == 0) {
			return 0;
		}
		for (int i = 5; i < Math.sqrt(n); i = i + 6) {
			if (n % i == 0 || n % (i + 2) == 0) {
				return 0;
			}
		}
		return 1;
	}

}
