package simple;

public class Numbertochar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=9;i++)
		{
			char ch=Character.forDigit(i, 10);
			System.out.println(ch);
		}

	}

}
