package simple;
import java.util.Scanner;

public class anajudeloitte {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		String s1=sc.next();
		int sum=0;
		int j=0;
		while(j<s.length())
		{
			sum=sum+(s.charAt(j)-s1.charAt(j));
			j++;
		}
		
    System.out.println(sum);
	}

}
