package simple;
import java.util.*;
public class ReverseANumber {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner sc=new Scanner(System.in);
   System.out.println("Enter the  Number");
   int num=sc.nextInt();
   sc.close();
   int count=0;
   int sum=0;
   int rev=0;
   while(num!=0)
   {
	   rev=rev*10 + num%10;
	   sum=sum+(num%10);
	   num=num/10;
	   count++;
   }
   
   System.out.println("reverse the number"+rev);
   System.out.println("sum of digits"+sum);
   System.out.println("Number of digits"+count);
	}

}
