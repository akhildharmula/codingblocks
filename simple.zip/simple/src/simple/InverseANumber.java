package simple;
import java.util.*;
// input:32145
// output:12543
//Inverse of the Number
// if a is in b th position in input
//then b should be in a th position in output
public class InverseANumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		   System.out.println("Enter the Number");
		   int num=sc.nextInt();
		   sc.close();
		   int in=0;
		   int place=1;
		   while(num!=0)
		   {
			   int rem=num%10;
			   in=in+(place *(int) Math.pow(10,rem-1));
			   num=num/10;
			   place++;
		   }
		   System.out.println("Inverse Number "+in);
	}

}
