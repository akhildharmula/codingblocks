package simple;

public class factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	System.out.println(fact(10));

	}

	private static int fact(int i) {
		// TODO Auto-generated method stub
		if(i==0)
		{
			return 1;
		}
		return i*fact(i-1);
	}

}
