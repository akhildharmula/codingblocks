package Practice;
import java.util.*;
public class SubSequencesOfstring {
	public static void main(String[] args) {
		String s="ab";
		//print(s,"");
		char s2[]=s.toCharArray();
        Arrays.sort(s2,0,s2.length-1);
        s=""+s2.toString();
        System.out.println(s);
		
	}

	private static void print(String s, String ans) {
		// TODO Auto-generated method stub
		if(s.length()==0)
		{
			System.out.println(ans);
			return;
		}
		print(s.substring(1),ans);
		print(s.substring(1),ans+s.charAt(0));
		
	}

}
