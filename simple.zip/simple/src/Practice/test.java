package Practice;
import java.util.*;
public class test {

	public static int print(int arr[],int score,int sum,int idx,int currsum)
    {
        if(currsum==sum-currsum)
        {
            score++;
            score=print(arr,score,currsum,idx,0);
            return score;
        }
        if(currsum>sum-currsum)
        {
            return score;
        }
        if(idx==arr.length)
        {
            return score;
        }
        score=print(arr,score,sum,idx+1,currsum+arr[idx]);
      
      return score;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
           int n=sc.nextInt();
           int arr[]=new int[n];
           int sum=0;
           for(int i=0;i<n;i++)
           {
               arr[i]=sc.nextInt();
               sum+=arr[i];
           }
           int score=0;
           if(sum!=0)
           {
              score=print(arr,score,sum,0,0);
           }
           else{
               score=arr.length-1;
           }
           System.out.println(score);

	}

}
