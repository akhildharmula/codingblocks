package Practice;
import java.util.*;
public class ArraySubArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {1,2,3,4,5};
		ArrayList<ArrayList<Integer>> l=new ArrayList<>();
		subarray(arr,0,0,l);
		print(arr);
		System.out.println(l);
		System.out.println(l.size());
		

	}

	private static void print(int[] arr) {
		// TODO Auto-generated method stub
		int count=0;
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i;j<arr.length;j++)
			{
				for(int k=i;k<=j;k++)
				{
					System.out.print(arr[k]+" ");
				}
				System.out.println();
				count++;
			}
		}
		System.out.println("No of subarrays :"+count);
		
	}

	private static void subarray(int[] arr, int start,int end, ArrayList<ArrayList<Integer>> l) {
		// TODO Auto-generated method stub
		if(start==arr.length)
		{
		  return;
		}
		if(end==arr.length)
		{
			subarray(arr,start+1,start+1,l);
		}
		else
		{
			ArrayList<Integer> temp=new ArrayList<>();
			for(int i=start;i<=end;i++)
			{
				temp.add(arr[i]);	
			}
			l.add(temp);
			subarray(arr,start,end+1,l);
			
		}
		
	}

}
