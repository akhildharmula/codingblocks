package Stack;

public class stack {

	int data[];
	int top;
	 public stack()
	 {
		 data=new int[5];
		 top=-1;
	 }
	 public stack(int size)
	 {
		 data=new int[size];
		 top=-1;
	 }
	 public boolean isempty()
	 {
		 return top==-1;
	 }
	 public boolean isfull()
	 {
		 return top==data.length-1;
	 }
	 public int peek()throws Exception
	 {
		 if(!isempty())
		 return data[top];
		 throw new Exception("Stack is empty");
	 }
	 public int size()
	 {
		 return data.length;
	 }
	 public void pop() throws Exception
	 {
		 if(!isempty())
		 {
			 top--;
			 return;
		 }
		 throw new Exception("Stack is empty");
	 }
	 public void push(int ele)throws Exception
	 {
		 if(!isfull())
		 {
			 top++;
			 data[top]=ele;
			 return;
			 
		 }
		 throw new Exception("Stack is full");
	 }
	 public void display() throws Exception
	 {
		 if(!isempty())
		 {
			 for(int i=0;i<=top;i++)
			 {
				 System.out.println(data[i]+" ");
			 }
			 return;
		 }
		 throw new Exception("Stack is Empty");
	 }

}
