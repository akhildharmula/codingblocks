package Stack;
import java.util.*;
public class test {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		Dystack s=new Dystack();
		s.push(10);
		s.push(20);
		s.push(30);
		s.push(10);
		s.push(20);
		s.push(30);
		s.display();
		
	
		

	}

}
