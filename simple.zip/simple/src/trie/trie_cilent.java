package trie;

public class trie_cilent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String words[]= {"app","apple","rame","Rajesh"};
		trie t=new trie();
		for(int i=0;i<words.length;i++)
		{
			t.addword(words[i]);
		}
		System.out.println(t.countwords("app"));
		System.out.println(t.startswith("Raj"));
		System.out.println(t.search("Rajesh"));
		

	}

}
