package trie;
import java.util.*;
public class trie {
	class node
	{
	    char data;
	    int count=0;
	    boolean terminate=false;
	    HashMap<Character,node> child=new HashMap<>();
	    public node()
	    {
	    	
	    }
	    public node(char ch)
	    {
	    	this.data=ch;
	    	this.count=1;
	    }
	}
	
	node root;
	public trie()
	{
		this.root=new node();
	}
	
	public void addword(String word)
	{
		node curr=this.root;
		for(int i=0;i<word.length();i++)
		{
			char ch=word.charAt(i);
			if(curr.child.containsKey(ch))
			{
				curr.count+=1;
				curr=curr.child.get(ch);
			}
			else
			{
				node nn=new node(ch);
				curr.child.put(ch,nn);
				curr=nn;	
			}
		}
		curr.terminate=true;
	}
	
	public boolean search(String word)
	{
		node curr=this.root;
		for(int i=0;i<word.length();i++)
		{
			char ch=word.charAt(i);
			if(curr.child.containsKey(ch))
			{
				curr=curr.child.get(ch);
			}
			else
			{
				return false;
			}
		}
		return curr.terminate;
	}
	
	
	public boolean startswith(String word)
	{
		node curr=this.root;
		for(int i=0;i<word.length();i++)
		{
			char ch=word.charAt(i);
			if(curr.child.containsKey(ch))
			{
				curr=curr.child.get(ch);
			}
			else
			{
				return false;
			}
		}
		return true;
	}
	
	
	public int countwords(String word)
	{
		node curr=this.root;
		for(int i=0;i<word.length();i++)
		{
			char ch=word.charAt(i);
			if(curr.child.containsKey(ch))
			{
				curr=curr.child.get(ch);
			}
			else
			{
				return 0;
			}
		}
		return curr.count;
	}
	

}
