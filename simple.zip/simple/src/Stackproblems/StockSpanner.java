package Stackproblems;
import java.util.*;
public class StockSpanner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {100,80,60,70,60,75,85};
		         // 1,  1,  1, 2, 1, 4, 6
		int [] res=new int[arr.length];
		Stack<Integer> st=new Stack<>();
		
		for(int i=0;i<arr.length;i++)
		{
			while(!st.empty() && arr[i]>=arr[st.peek()])
			{
				st.pop();
			}
			if(st.empty())
			{
				res[i]=i+1;
			}
			else
			{
				res[i]=i-st.peek();
			}
			st.push(i);
		}
		
		/*
		for(int i=0;i<arr.length;i++)
		{
			int cnt=1;
			cnt=getcnt(st,arr[i],cnt);
			res[i]=cnt;
			st.push(arr[i]);
		}
		*/
		for(int k:res)
		{
			System.out.print(k+" ");
		}
		
	}

	private static int getcnt(Stack<Integer> st,int tar,int cnt) {
		// TODO Auto-generated method stub
		if(st.empty() || tar<st.peek())
		{
			return cnt;
		}
		else
		{
			cnt++;
			int val=st.pop();
			cnt=getcnt(st,tar,cnt);
			st.push(val);
		}
		return cnt;
	}

}
