package Arrays;
import java.util.*;
public class IntersectionofArrays {
	public static boolean binarysearch(int[] arr,int target)
    {
        int start=0;
        int end=arr.length-1;
        while(start<=end)
        {
            int mid=start+(end-start)/2;
            if(arr[mid]==target)
            {
                return true;
            }
            if(target<arr[mid])
            {
                end=mid-1;
            }
            if(target >arr[mid])
            {
                start=mid+1;
            }
        }
        return false;
    }
    public static int[] intersection(int[] nums1, int[] nums2) {
        Arrays.sort(nums1);
        Arrays.sort(nums2);
        int k=1;
        for(int i=1;i<nums1.length;i++)
        {
            if(nums1[i-1]!=nums1[i])
            {
              nums1[k]=nums1[i];
              k++;
            }
        }
        int n=k;
        for(int i=0;i<nums1.length;i++)
		{
			System.out.print(nums1[i]+" ");
		}
        System.out.println();
        k=1;
        for(int i=1;i<nums2.length;i++)
        {
            if(nums2[i-1]!=nums2[i])
            {
              nums2[k]=nums2[i];
              k++;
            }
        }
        for(int i=0;i<nums2.length;i++)
		{
			System.out.print(nums2[i]+" ");
		}
        int m=k;
        ArrayList<Integer> ans=new ArrayList<>();
        for(int i=0;i<n;i++)
        {
           if(binarysearch(nums2,nums1[i]))
           {
               ans.add(nums1[i]);
           }
        }
        int[] finalans=new int[ans.size()];
        for(int i=0;i<ans.size();i++)
        {
            finalans[i]=ans.get(i);
        }

       return finalans;
        
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] ans;
		int nums1[]= {4,9,5};
		int nums2[]= {9,4,9,8,4};
		ans=intersection(nums1,nums2);
		for(int i=0;i<ans.length;i++)
		{
			System.out.println(ans[i]);
		}
		

	}

}
