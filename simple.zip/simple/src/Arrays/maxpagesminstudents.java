package Arrays;


import java.util.Scanner;

public class maxpagesminstudents {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the  number of books");
		int n = sc.nextInt();
		System.out.println("Enter the  number of students");
		int s = sc.nextInt();
		int b[] = new int[n];
		System.out.println("Enter the  pages of books");
		for (int i = 0; i < n; i++) {
			b[i] = sc.nextInt();
		}
		int count = minstudentsmaxpages(b,s);
		System.out.println("max pages min students");
		System.out.println(count);
		sc.close();
	}

	private static int minstudentsmaxpages(int[] b, int s) {
		// TODO Auto-generated method stub
		int ans=0;
		int start=0;
		int end=0;
		for(int k: b)
		{
            end+=k;
		}
		while(start<=end)
		{
			int mid=start+(end-start)/2;
			if(isitpossible(mid,s,b))
			{
				ans=mid;
				end=mid-1;
			}
			else
			{
				start=mid+1;
			}
		}
		return ans;
	}

	private static boolean isitpossible(int mid, int s, int[] b) {
		// TODO Auto-generated method stub
		int nstudents=1;
		int pagesread=0;
		int i=0;
		while(i<b.length)
		{
			if(b[i]+pagesread <=mid) {
				pagesread+=b[i];
				i++;
			}
			else
			{
				nstudents++;
				pagesread=0;
			}
			if(nstudents>s)
			{
				return false;
			}
		}
		return true;
	}

}
