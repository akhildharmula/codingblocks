package Arrays;

import java.util.Scanner;

public class TappingRainWater {
	public static int trap(int[] height) {
        int left[]=new int[height.length];
        int max=height[0];
        for(int i=0;i<height.length;i++)
        {
            if(height[i]>max){
                max=height[i];
            }
            left[i]=max;
        }

        int right[]=new int[height.length];
        max=height[height.length-1];
        for(int i=height.length-1;i>=0;i--)
        {
            if(height[i]>max){
                max=height[i];
            }
            right[i]=max;
        }
        int ans=0;
        for(int i=0;i<height.length;i++)
        {
            ans=ans+(Math.min(left[i],right[i])-height[i]);
        }
        return ans;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter the Elements array");
		for (int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		sc.close();
		int ele=trap(arr);
		System.out.println(ele);

	}

}
