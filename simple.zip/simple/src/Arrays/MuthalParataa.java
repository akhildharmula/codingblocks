package Arrays;
import java.util.*;
public class MuthalParataa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc=new Scanner(System.in);
	        int p=sc.nextInt();
	        int c=sc.nextInt();
	        int ranks[]=new int[c];
	        int level[]=new int[c];
	        int rankscopy[]=new int[c];
	      
	        for(int i=0;i<c;i++)
	        {
	            ranks[i]=sc.nextInt();
	            rankscopy[i]=ranks[i];
	            level[i]=1;
	        }
	        int p1=p;
	        sc.close();
	        int t=0;
	        while(p>0)
	        {
	        	t++;
	        	for(int i=0;i<c;i++)
	            {
	                if(t>=ranks[i])
	                {
	                    p--;
	                   level[i]+=1;
	                   ranks[i]+=(level[i]*rankscopy[i]);
	                }
	            }
	        }
	        System.out.println(muthal(rankscopy,p1));
	        System.out.println(t);

	}
    
	private static int muthal(int[] ranks, int n) {
		// TODO Auto-generated method stub
		int start=0;
		int end=(((n)*(n+1))*max(ranks))/2;
		int ans=0;
		while(start<=end)
		{
			int mid=start+(end-start)/2;
			if(ispossible(mid,ranks,n))
			{
				ans=mid;
				end=mid-1;
			}
			else
			{
				start=mid+1;
			}
		}
		return ans;
		
	}

	private static boolean ispossible(int mid,int[] ranks,int np) {
		
		// TODO Auto-generated method stub
		int p=0;
		for(int i=0;i<ranks.length;i++)
		{
			int r=ranks[i];
			int nop=0;
			int k=1;
			int time=0;
			while(time+r*k<=mid) {
				time=time+r*k;
				nop++;
				k++;
			}
			p+=nop;
		}
		if(p>=np)
		{
			return true;
		}
		
		return false;
	}

	private static int max(int[] ranks) {
		// TODO Auto-generated method stub
		int max=Integer.MIN_VALUE;
		for(int i=0;i<ranks.length;i++)
		{
			if(ranks[i]>max)
			{
				max=ranks[i];
			}
		}
		return max;
	}

}
