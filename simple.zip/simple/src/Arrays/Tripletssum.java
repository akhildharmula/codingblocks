package Arrays;
import java.util.*;
public class Tripletssum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		int target=sc.nextInt();
		sc.close();
		Arrays.sort(arr);
		for(int i=0;i<n;i++)
		{
			int start=i+1;
			int end=n-1;
			while(start<end)
			{
				if(arr[i]+arr[start]+arr[end]==target)
				{
					System.out.println(arr[i]+" "+arr[start]+" "+arr[end]);
					start++;
					end--;
				}
				else
				{
					if(arr[i]+arr[start]+arr[end]<target)
					{
						start++;
					}
					else
					{
						end--;
					}
				}
			}

			
		}
		
	}

}
