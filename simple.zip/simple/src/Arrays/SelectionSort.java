package Arrays;

import java.util.Scanner;

public class SelectionSort {
    public static void slectionsort(int arr[])
    {
    	for(int i=0;i<arr.length;i++)
    	{
    		int key=i;
    		for(int j=i+1;j<arr.length;j++)
    		{
    			if(arr[j]<arr[key])
    			{
    				key=j;
    			}
    		}
    		int t=arr[key];
    		arr[key]=arr[i];
    		arr[i]=t;
    	}
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter the Elements array");
		for (int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		sc.close();
		slectionsort(arr);
		System.out.println("sorted Array");
		for (int i = 0; i < n; i++) {
			System.out.print(arr[i] + " ");
		}
	}

}
