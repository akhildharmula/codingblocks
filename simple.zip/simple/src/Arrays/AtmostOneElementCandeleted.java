package Arrays;

public class AtmostOneElementCandeleted {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {1,2,5,3,4};
		System.out.println(print(arr));

	}

	private static int  print(int[] arr) {
		// TODO Auto-generated method stub
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i-1]<arr[i])
			{
				if(i==arr.length-1)
					
				{
					return arr.length;
				}
				
			}
		}
		
		return 0;
	}

}
