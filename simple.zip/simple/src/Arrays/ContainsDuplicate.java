package Arrays;

public class ContainsDuplicate {
	 public static boolean containsNearbyDuplicate(int[] nums, int k) {
	        
	        for(int i=0;i<nums.length;i++)
	        {
	            for(int j=i+1;j<=i+k;j++)
	            {
	                if(i!=j)
	                {
	                	System.out.println(Math.abs(i-j));
	                    if(nums[i]==nums[j] && Math.abs(i-j)<=k)
	                    {
	                        return true;
	                    }
	                }
	                
	            }
	        }
	        return false;
	       
	        
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int [] nums = {1,0,1,1};
		 int k = 1;
		 System.out.println(containsNearbyDuplicate(nums,k));

	}

}
