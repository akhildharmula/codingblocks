package Arrays;

public class Mergesort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            int arr[]= {5,4,1,2,3};
            arr=mergesort(arr,0,arr.length-1);
            for(int k:arr)
            {
            	System.out.print(k+" ");
            }
	}

	private static int[] mergesort(int[] arr, int start, int end) {
		
		// TODO Auto-generated method stub
		if(start==end)
		{
			int []sig=new int[1];
			sig[0]=arr[start];
			return sig;
		}
		int mid=(start+end)/2;
		
		int[] fi=mergesort(arr,start,mid);
		int[] se=mergesort(arr,mid+1,end);
		return mergetwosortedarrays(fi,se);
	}

	private static int[] mergetwosortedarrays(int[] fi, int[] se) {
		// TODO Auto-generated method stub
		int i=0,j=0,k=0;
		int [] ans=new int[fi.length+se.length];
		while(i<fi.length && j<se.length)
		{
			if(fi[i]<se[j])
			{
				ans[k]=fi[i];
				i++;
			}
			else
			{
				ans[k]=se[j];
				j++;
			}
			k++;
		}
		while(j<se.length)
		{
			ans[k]=se[j];
			j++;
			k++;
		}
		while(i<fi.length)
		{
			ans[k]=fi[i];
			i++;
			k++;
		}
		return ans;
	}

}
