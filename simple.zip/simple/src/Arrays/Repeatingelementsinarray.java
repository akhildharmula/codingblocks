package Arrays;

import java.util.*;

public class Repeatingelementsinarray {
	public static int RepeatingElementlogic(int a[]) {
		int sum = 0;
		for (int i = 0; i < a.length; i++) {
			sum = sum + a[i];
		}
		int n=a.length-1;
		int totalsum = (n * (n + 1)) / 2;
		return sum - totalsum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter the Elements array");
		for (int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		sc.close();
		int ele = RepeatingElementlogic(arr);
		System.out.println(ele);

	}

}
