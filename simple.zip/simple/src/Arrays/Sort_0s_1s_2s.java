package Arrays;

import java.util.Scanner;

public class Sort_0s_1s_2s {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter the Elements array");
		for (int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		sc.close();
		sortlogic(arr);
		System.out.println("sorted Array");
		for (int i = 0; i < n; i++) {
			System.out.print(arr[i] + " ");
		}

	}

	private static void sortlogic(int[] arr) {
		// TODO Auto-generated method stub
		int start=0;
		int end=arr.length-1;
		int mid=0;
		while(mid<=end)
		{
			if(arr[mid]==0)
			{
				int t=arr[mid];
				arr[mid]=arr[start];
				arr[start]=t;
				start++;
				mid++;
			}
			 else if(arr[mid]==2)
			{  
				 int t=arr[mid];
					arr[mid]=arr[end];
					arr[end]=t;
					end--;
				
			}
			 else
			 {
				 mid++;
			 }
		}
		
	}

}
