package Arrays;
import java.util.*;
public class nextGreaterElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arr[]= {10,11,19,18,7,6,25};
		//int arr[]= {12,9,4,12,9,4,12,9,4};
		
		//using stack
		 int ans[]=new int[arr.length];
		 Stack<Integer> s=new Stack<>();
		 for(int i=0;i<arr.length;i++)
		 {
			 while(!s.empty() && arr[i] > arr[s.peek()])
			 {
				 ans[s.pop()]=arr[i];
			 }
			 s.push(i);
		 }
		 for(int k:ans)
		 {
			 System.out.print(k+" ");
		 }
		 //Without using stack
		
		int maxx=0;
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]>arr[0])
			{
				maxx=arr[i];
				break;
			}
		}
		int max=0;
		for(int i=arr.length-1;i>=0;i--)
		{
			int t=arr[i];
			arr[i]=max;
			if(i>0 && arr[i-1]<t)
			{
				max=t;
			}
			
		}
		 
		arr[0]=maxx;
		System.out.println();
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}

	}

}
