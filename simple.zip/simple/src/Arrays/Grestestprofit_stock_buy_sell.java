package Arrays;

import java.util.Scanner;

public class Grestestprofit_stock_buy_sell {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter the Elements array");
		for (int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		sc.close();
		int ele=GreatestProfit(arr);
		int ele2=GreatestProfit2(arr);
		System.out.println(ele);
		System.out.println(ele2);

	}

	private static int GreatestProfit2(int[] arr) {
		// TODO Auto-generated method stub
		int minin=0;
		int max=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]<arr[minin]) {
				minin=i;
			}
		}
		for(int i=arr.length-1;i>=minin;i--)
		{
			max=Math.max(max, arr[i]);
		}
		return max-arr[minin];
	}

	private static int GreatestProfit(int[] arr) {
		// TODO Auto-generated method stub
		int a[]=new int[arr.length];
		int max=0;
		for(int i=arr.length-1;i>=0;i--)
		{
			max=Math.max(max, arr[i]);
			a[i]=max;
		}
		max=0;
		for(int i=0;i<arr.length;i++)
		{
			max=Math.max(max, a[i]-arr[i]);
		}
		
		return max;
	}

}
