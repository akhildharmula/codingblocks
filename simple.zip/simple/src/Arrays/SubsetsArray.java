package Arrays;
import java.util.*;
public class SubsetsArray {
	public static void logic(int[] nums,List<Integer> l,List<List<Integer>> ans,int idx,boolean vis[])
    {
         ans.add(new ArrayList<>(l));
        if(idx==nums.length)
        {
            return;
        }

        for(int i=idx;i<nums.length;i++)
        {
        	if(searchpresent(nums,vis,i))
        	{
        		l.add(nums[i]);
        		vis[i]=true;
                logic(nums,l,ans,i+1,vis);
                l.remove(l.size()-1);
                vis[i]=false;
        	}
        	
        }
    }
   public static boolean searchpresent(int nums[],boolean vis[],int start)
   {
	   for(int i=0;i<start;i++)
	   {
		   if(nums[i]==nums[start] && vis[i]==false)
		   {
			   return false;
		   }
	   }
	   return true;
   }
	public static List<List<Integer>> subsets(int[] nums) {
        List<List<Integer>> ans=new ArrayList<>();
        List<Integer> l=new ArrayList<>();
        boolean[] vis=new boolean[nums.length];
        logic(nums,l,ans,0,vis);
        return ans;
        
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<List<Integer>> ans=new ArrayList<>();
		int nums[]={1,2,3};
		ans=subsets(nums);
		System.out.println(ans);

	}

}
