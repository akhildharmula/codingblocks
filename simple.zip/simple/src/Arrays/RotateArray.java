package Arrays;
import java.util.*;
public class RotateArray {
	/*
    public static void RotateArraylogic(int[] arr,int n,int k) {
    	int rot[]=new int[n];
    	int j=0;
    	k=k%arr.length;
    	for(int i=arr.length-k;i<arr.length;i++)
    	{
    		rot[j]=arr[i];
    		j++;
    	}
    	for(int i=0;i<arr.length-k;i++)
    	{
    		rot[j]=arr[i];
    		j++;
    	}
    	for(int i=0;i<arr.length;i++)
    	{
    		arr[i]=rot[i];
    	}
    } */
	public static void ReverseofArray(int arr[],int start,int end)
	{
		while(start<end)
		{
			int t=arr[start];
			arr[start]=arr[end];
			arr[end]=t;
			start++;
			end--;
		}
		
	}
    public static void BestRotateArraylogic(int[] arr,int k) {
    	k=k%arr.length;
    	int n=arr.length-1;
    	ReverseofArray(arr,0,n-k);
    	ReverseofArray(arr,n-k+1,n);
    	ReverseofArray(arr,0,n);
    }
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter the size of the array");
     int n=sc.nextInt();
     int arr[]=new int[n];
     System.out.println("Enter the Elements array");
     for(int i=0;i<n;i++)
     { 
    	 arr[i]=sc.nextInt();
     }
     System.out.println("Enter the Number of rotations to be done");
     int k=sc.nextInt();
     sc.close();
     BestRotateArraylogic(arr,k);
     System.out.println("Rotated Array");
     for(int i=0;i<n;i++)
     {
    	 System.out.print(arr[i]+" ");
     }
	}

}
