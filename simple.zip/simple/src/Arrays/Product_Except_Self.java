package Arrays;

import java.util.Scanner;

public class Product_Except_Self {
	public static int[] productExceptSelf(int[] nums) {
        int mul=1;
      int left[]=new int[nums.length];
       for(int i=0;i<nums.length;i++)
       {
           left[i]=mul;
           mul*=nums[i];
       }
       mul=1;
       for(int i=nums.length-1;i>=0;i--)
       {
           left[i]*=mul;
           mul*=nums[i];
       }
       return left;
    } 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter the Elements array");
		for (int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		sc.close();
		arr=productExceptSelf(arr);
		System.out.println("Procuct except Self Array");
		for (int i = 0; i < n; i++) {
			System.out.print(arr[i] + " ");
		}

	}

}
