package Dp;

public class zerooneknapsack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int weights[]= {5,3,2,4};
		int value[]= {4,5,1,3};
		int n=2;
		int[][] dp=new int[weights.length][n+1];
		System.out.println(logic(weights,value,0,n,dp));
		

	}

	private static int logic(int[] weights, int[] value, int i, int w,int[][] dp) {
		// TODO Auto-generated method stub
		if(w==0 || i>=weights.length)
		{
			return 0;
		}
		if(dp[i][w]!=0)
		{
			return dp[i][i];
		}
		int inc=0;
		
		if(w>=weights[i])
		{
			inc+=value[i]+logic(weights,value,i+1,w-weights[i],dp);
		}
		int exc=0;
		exc+=logic(weights,value,i+1,w,dp);
		return dp[i][w]=Math.max(inc, exc);
	}

}
