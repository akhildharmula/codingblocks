package Queue;

public class StackUsingQueue {
	queue p=new queue();
	queue s=new queue();
	
  public void push(int val)throws Exception
  {
		  while(!p.isempty())
		  {
			  s.enqueue(p.dequeue());
		  }
		  p.enqueue(val);
		  while(!s.isempty())
		  {
			  p.enqueue(s.dequeue());
		  }
	  
  }
}
