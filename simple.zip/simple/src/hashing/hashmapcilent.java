package hashing;

public class hashmapcilent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		hashmap<Integer,Integer> hm=new hashmap<>();
		hm.put(2, 1);
		hm.put(34, 8);
		hm.put(6, 10);
		hm.put(8, 11);
		hm.display();
		System.out.println();
		System.out.println(hm.getval(34));
		hm.put(10, 67);
		hm.put(11, 6);
		hm.display();
		System.out.println();
		
		

	}

}
