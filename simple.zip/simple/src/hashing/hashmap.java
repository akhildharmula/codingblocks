package hashing;
import java.util.*;
public class hashmap<k,v> {
	public class node
	{
		k key;
		v val;
		node next;
		
		public node()
		{
			
		}
		public node(k key,v val)
		{
			this.key=key;
			this.val=val;
			this.next=null;
		}
	}
	ArrayList<node> bucketarray;
	int size=0;
	public hashmap(int x)
	{
		bucketarray=new ArrayList<>();
		for(int i=0;i<x;i++)
		{
			bucketarray.add(null);
		}
	}
	public hashmap()
	{
		this(4);
	}
	public void put(k key,v val)
	{
		int bn=hashfunction(key);
		node temp=bucketarray.get(bn);
		while(temp!=null)
		{
			if(temp.key.equals(key))
			{
				temp.val=val;
				return;
			}
			temp=temp.next;
		}
		temp=bucketarray.get(bn);
		node nn=new node(key,val);
		nn.next=temp;
		bucketarray.set(bn, nn);
		size++;
		double lf=(1.0 * this.size)/this.bucketarray.size();
		double thf=2.0;
		if(lf>thf)
		{
			rehashing();
		}
		
	}
	private void rehashing() {
		// TODO Auto-generated method stub
		ArrayList<node> newbucketarray=new ArrayList<>();
		for(int i=0;i<2*this.bucketarray.size();i++)
		{
			newbucketarray.add(null);
		}
		ArrayList<node> oba=this.bucketarray;
		this.bucketarray=newbucketarray;
		for(node n:oba)
		{
			while(n!=null)
			{
				put(n.key,n.val);
				n=n.next;
			}
		}
		
	}
	private int hashfunction(k key) {
		// TODO Auto-generated method stub
		int bn=key.hashCode() % this.bucketarray.size();
		if(bn<0)
		{
			bn+=this.bucketarray.size();
		}
		return bn;
	}
	
	public void display()
	{
		String s=toString();
		System.out.println(s);
	}
	public String toString()
	{
		String s="{";
		for(node n:this.bucketarray)
		{
			while(n!=null)
			{
				s= s + n.key +"==" + n.val +",";
				n=n.next;
			}
		}
		s=s+"}";
		return s;
		
	}
	public v getval(k key)
	{
		int bn=hashfunction(key);
		node temp=bucketarray.get(bn);
		while(temp!=null)
		{
			if(temp.key.equals(key))
			{
				
				return temp.val;
			}
			temp=temp.next;
		}
		
		return null;
	}

}
