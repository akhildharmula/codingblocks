package NumberSystem;
import java.util.*;
public class DecimaltoBinary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        sc.close();
        int bi=0;
        int mul=1;
        while(n!=0)
        {
        	int rem=n%2;
        	n=n/2;
        	bi=bi+(rem*mul);
        	mul=mul*10;
        }
        System.out.println(bi);
	}

}
