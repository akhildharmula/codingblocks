package NumberSystem;
import java.util.*;
public class DemcimaltoOctal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc=new Scanner(System.in);
    System.out.println("Enter the decimal Number");
     int n=sc.nextInt();
     sc.close();
     int oc=0;
     int mul=1;
     while(n!=0)
     {
    	 int rem=n%8;
    	 n=n/8;
    	 oc=oc+(mul*rem);
    	 mul=mul*10;
     }
     System.out.println(oc);
	}

}
