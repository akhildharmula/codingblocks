package BinarysearchTree;

public class BSTCLIENT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {6,7,8,9,10,12,15,16};
		Binarysearchtree b=new Binarysearchtree(arr);
		b.preorder();
		System.out.println(b.find(9));
		b.insert(60);
		b.preorder();

	}

}
