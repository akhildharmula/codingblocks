package BinarysearchTree;
//inorder traversal of binary search tree is sorted order
import java.util.*;
public class Binarysearchtree {
Scanner sc=new Scanner(System.in);
	public class node
	{
		int data;
		node left;
		node right;
		public node()
		{
			
		}
		public node(int data)
		{
			this.data=data;
		}
		
	}
	
	private node root;
	public Binarysearchtree()
	{
		
	}
	public  Binarysearchtree(int[] arr)
	{
		root=createnode(arr,0,arr.length-1);
	}
	private node createnode(int[] arr,int start,int end)
	{
		if(start>end) {
			return null;
		}
		int mid=(start+end+1)/2;
		node nn=new node(arr[mid]);
		nn.left=createnode(arr,start,mid-1);
		nn.right=createnode(arr,mid+1,end);
		return nn;
	}
	public void preorder()
	{
		preorder(this.root);
	}
	private void preorder(node root) {
		// TODO Auto-generated method stub
		if(root==null)
		{
			return;
		}
		System.out.print(root.data+" ");
		preorder(root.left);
		preorder(root.right);
		
	}
	public boolean find(int data)
	{
		return find(root,data);
	}
	private boolean find(node root, int data) {
		// TODO Auto-generated method stub
		if(root==null)
		{
			return false;
		}
		if(root.data==data)
		{
			return true;
		}
		boolean temp=false;
		if(root.data<data)
		{
			temp=find(root.right,data);
		}
		else
		{
			temp=find(root.left,data);
		}
		
		return temp;
	}
	public void insert(int key)
	{
		insert(root,key);
	}
	private void insert(node root, int key) {
		// TODO Auto-generated method stub
		if(key > root.data)
		{
			if(root.right==null)
			{
				root.right=new node(key);
				return;
			}
			insert(root.right,key);
		}
		else
		{
			if(root.left==null)
			{
				root.left=new node(key);
				return;
			}
			insert(root.left,key);
		}
	}
	
	

}
