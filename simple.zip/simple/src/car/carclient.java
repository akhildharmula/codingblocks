package car;
import java.util.*;
public class carclient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		car[] s=new car[5];
		 s[0]=new car(10,45,"bule");
		 s[1]=new car(10,45,"orange");
		 s[2]=new car(10,45,"bule");
		 s[3]=new car(10,45,"bule");
		 s[4]=new car(10,45,"bule");
		
		LinkedList<Integer> ll=new LinkedList<>();
		ll.s

	}

}
