package patterns;
import java.util.*;
public class Pattern9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter a Nmumber");
      int n=sc.nextInt();
      sc.close();
      int nst=1;
      int nsp=(2*n)-3;
      for(int i=0;i<n;i++) {
    	  for(int j=0;j<nst;j++)
    	  {
    		  System.out.print("* ");
    	  }
    	  for(int j=0;j<nsp;j++)
    	  {
    		  System.out.print("  ");
    	  }
    	  if(i==(n-1))
    	  {
    		  nst=nst-1;
    	  }
    	  for(int j=0;j<nst;j++)
    	  {
    		  System.out.print("* ");
    	  }
    	  System.out.println();
    	  nst=nst+1;
    	  nsp=nsp-2;
    	  
      }
	}

}
