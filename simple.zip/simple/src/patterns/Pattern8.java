package patterns;
import java.util.*;
public class Pattern8 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		sc.close();
		int s=n;
		int t=0;
		for(int i=0;i<(2*n)-1;i++)
		{
			for(int j=0;j<t;j++)
			{
				System.out.print("  ");
			}
			for(int k=0;k<s;k++)
			{
				System.out.print("* ");
			}
			if(i<n-1)
			{
				t=t+2;
				s=s-1;
			}
			else
			{
				t=t-2;
				s=s+1;
			}
			System.out.println();
		}

	}

}
