package patterns;
import java.util.*;
/*
        # 
      # ! # 
    # ! # ! # 
  # ! # ! # ! # 
# ! # ! # ! # ! # 
 */
public class Pattern6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Number");
		int n=sc.nextInt();
		sc.close();
		int h=1;
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<(n-i-1);j++)
			{
					System.out.print("  ");
			}
			for(int j=1;j<=h;j++)
				{
				    if(j%2==0)
				    {
				    	System.out.print("! ");
				    }
				    else
				    {
				    	System.out.print("# ");
				    }
					
				}
			h=h+2;
			
			System.out.println();
			
		}
	}

}
