package heap;

public class heap1client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		heap1 a=new heap1();
		a.add(10);
		a.add(20);
		a.add(3);
		a.add(5);
		a.add(70);
		a.add(90);
		a.add(-10);
		a.display();
		a.remove(0);
		System.out.println();
		a.display();
		heap1 b=new heap1();
		System.out.println();
		b.add(10);
		b.add(20);
		b.add(3);
		b.add(5);
		b.add(70);
		b.add(90);
		b.display();
		

	}

}
