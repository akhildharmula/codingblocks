package heap;

import java.util.*;

public class heap1 {
	private ArrayList<Integer> data = new ArrayList<>();

	public void add(int item) {
		data.add(item);
		unheapifi(data.size() - 1);
	}

	private void unheapifi(int i) {
		// TODO Auto-generated method stub
		int ci = i;
		int pi = (ci - 1) / 2;
		int a = data.get(ci);
		int b = data.get(pi);
		if (a < b && ci != 0) {
			data.set(pi, a);
			data.set(ci, b);
			unheapifi(pi);
		}
	}
	
	public void remove(int item)
	{
		int a = data.get(item);
		int b = data.get(data.size()-1);
		data.set(data.size()-1, a);
		data.set(item, b);
		this.data.remove(data.size()-1);
		downheapifi(0);
	}

	private void downheapifi(int i) {
		// TODO Auto-generated method stub
		int rc= (2 *i)+2;
		int lc=(2*i)+1;
		int mini=i;
		if(rc<data.size()-1 && data.get(rc)<data.get(mini))
		{
			mini=rc;
		}
		if(lc<data.size()-1 && data.get(lc)<data.get(mini))
		{
			mini=lc;
		}
		if(mini!=i)
		{
			swap(mini,i);
			downheapifi(mini);
		}
		
	}

	private void swap(int i, int rc) {
		// TODO Auto-generated method stub
		int val1 = data.get(i);
		int val2 = data.get(rc);
		data.set(i, val2);
		data.set(rc, val1);
		
	}

	public void display() {
		System.out.println(this.data);
	}
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		int a[]= {10,20,3,5,70,90,-10};
//		int b[]= new int[a.length];
//		int pi,ci;
//		for(int i=0;i<a.length;i++)
//		{
//			b[i]=a[i];
//			ci=i;
//			pi=(ci-1)/2;
//			while(ci!=0 && b[ci]<b[pi])
//			{
//				int temp=b[ci];
//				b[ci]=b[pi];
//				b[pi]=temp;
//				ci=pi;
//				pi=(ci-1)/2;
//			}
//		}
//		for(int i=0;i<b.length;i++)
//		{
//			System.out.print(b[i]+" ");
//		}
//		
//
//	}

}
