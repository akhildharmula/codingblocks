package abstractionandinteface;

public class inteface1client implements inteface1, inteface2 {

	public void fun() {
		System.out.println("I am fun");
	}

	public void fun1() {
		System.out.println("I am fun1");
	}

	public void fun2() {
		System.out.println("I am fun2");
	}

}
