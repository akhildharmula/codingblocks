package TwoDArrays;

import java.util.Scanner;

public class Spiral {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the No of Rows");
		int n=sc.nextInt();
		System.out.println("Enter the No of columns");
		int m=sc.nextInt();
		int arr[][]=new int[n][m];
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		SpiralPrinting(arr);
		
		sc.close();

	}

	private static void SpiralPrinting(int[][] arr) {
		// TODO Auto-generated method stub
		int top=0,down=arr.length-1,left=0,right=arr[0].length-1;
		int dir=0;
	    while(left<=right && top<=down)
	    {
	    	if(dir==0)
	    	{
	    		for(int i=left;i<=right;i++)
	    		{
	    			System.out.print(arr[top][i]+" ");
	    		}
	    		top++;
	    	}
	    	if(dir==1)
	    	{
	    		for(int i=top;i<=down;i++)
	    		{
	    			System.out.print(arr[i][right]+" ");
	    		}
	    		right--;
	    	}
	    	if(dir==2)
	    	{
	    		for(int i=right;i>=left;i--)
	    		{
	    			System.out.print(arr[down][i]+" ");
	    		}
	    		down--;
	    		
	    	}
	    	if(dir==3)
	    	{
	    		for(int i=down;i>=top;i--)
	    		{
	    			System.out.print(arr[i][left]+" ");
	    		}
	    		left++;
	    	}
	    	dir=(dir+1)%4;
	    }
	}

}
