package TwoDArrays;

import java.util.Scanner;

public class WavePrinting2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the No of Rows");
		int n=sc.nextInt();
		System.out.println("Enter the No of columns");
		int m=sc.nextInt();
		int arr[][]=new int[n][m];
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		Printing2(arr);
		
		sc.close();

	}

	private static void Printing2(int[][] arr) {
		// TODO Auto-generated method stub
		int i=0,j=0;
		while(i<arr.length)
		{
			if(i%2==0)
			{
				while(j<arr[i].length)
				{
					System.out.print(arr[i][j]+" ");
					j++;
				}
				j--;
			}
			else
			{
				while(j>=0)
				{
					System.out.print(arr[i][j]+" ");
					j--;
				}
				j++;
				
			}
			i++;
		}
		
	}

}
