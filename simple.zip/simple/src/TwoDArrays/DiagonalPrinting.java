package TwoDArrays;

import java.util.Scanner;

public class DiagonalPrinting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the No of Rows");
		int n = sc.nextInt();
		System.out.println("Enter the No of columns");
		int m = sc.nextInt();
		int arr[][] = new int[n][m];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				arr[i][j] = sc.nextInt();
			}
		}
		diagonalPrinting(arr);
		sc.close();

	}

	private static void diagonalPrinting(int[][] arr) {
		// TODO Auto-generated method stub
		int j = 0,i=0;
		for (int k = 0; k < arr[0].length; k++) {
			if(j==0)
			{
				while (i >= 0) {
					System.out.print(arr[j][i] + " ");
					j++;
					i--;
				}
				i++;
				
			}
			else
			{
				while (j>= 0) {
					System.out.print(arr[j][i] + " ");
					j--;
					i++;
				}
				j++;
				
			}
		}
		/*for (int k = 1; k < arr.length; k++) {
			j = arr[0].length - 1;
			int i = k;
			while (i < arr.length) {
				System.out.print(arr[i][j] + " ");
				j--;
				i++;
			}
		}
           */
	}

}
