package practiceArrayList;
import java.util.*;
public class checking {

	public static void main(String[] args) {
		// TODO Auto-generated me thod stub
		List<Integer> ans= new ArrayList<>();
		ans.add(10);
		System.out.println(ans);
		logic(ans);
		System.out.println(ans);

	}

	private static void logic(List<Integer> ans) {
		// TODO Auto-generated method stub
		ans.add(20);
		ans.add(30);
		
	}

}
