package oops;

public class Student {
	String name="";
	int age;

	public void intro()
	{
		System.out.println("Name: "+this.name +" Age "+this.age);
	}

}
