package Strings;

public class CBnumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="81615";
		int c=0;
		boolean b[]=new boolean[s.length()];
		for(int i=0;i<b.length;i++)
		{
			b[i]=false;
		}
	for(int j=1;j<=s.length();j++)
	{
		for(int i=0;i<=s.length()-j;i++)
		{
			int end=i+j;
			if(iscbnumber(s.substring(i, end)) && isnotvis(i,end,b))
			{
				c++;
				System.out.println(s.substring(i, end));
				for(int k=i;k<end;k++)
				{
					b[k]=true;
				}
			}
		}
		
	}
	System.out.println(c);

	}

	private static boolean isnotvis(int i, int j, boolean[] b) {
		for(int k=i;k<j;k++)
		{
			if(b[k]) return false;
		}
		return true;
	}

	private static boolean iscbnumber(String substring) {
		long val=Long.parseLong(substring);
		if(val==1 || val==0)
		{
			return false;
		}
		int [] arr= {2,3,5,7,11,13,17,19,23,29};
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==val)
			{
				return true;
			}
		}
		
		for(int i=0;i<arr.length;i++)
		{
			if(val%arr[i]==0)
			{
				return false;
			}
		}
		return true;
	}

}
