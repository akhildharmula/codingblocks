package Strings;
import java.util.*;
public class ReverseWordsINString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		sc.close();
		System.out.println(reversewordsinstring(s));

	}

	private static String reversewordsinstring(String s) {
		// TODO Auto-generated method stub
		StringBuilder s1=new StringBuilder(s);
		s1.reverse();
		int start=0;
		int end=0;
		int n=s1.length();
		//System.out.println(s1.charAt(start)+" "+s1.charAt(end));
		while(start<n)
		{
			while(end<=n-1 && s1.charAt(end)!=' ')
			{
				end++;
			}
			StringBuilder s2=new StringBuilder(s1.substring(start,end));
			s2.reverse();
			s1.replace(start, end, s2.toString());
			end++;
			start=end;
			
		}
		//System.out.println(s1);
		
		return s1.toString();
	}

}
