package Strings;

public class GoodString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "cbaeicdeaiou";
		int ansl = 0;
		int endin = 0;
		int c = 0;
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == 'a' || s.charAt(i) == 'e' || s.charAt(i) == 'i' || s.charAt(i) == 'o'
					|| s.charAt(i) == 'u') {
				c++;
			} else {
				c = 0;
			}
			if (ansl < c) {
				ansl = c;
				endin = i;
			}

		}
		System.out.println(s.substring(endin - c + 1, endin + 1));
		System.out.println(ansl);

	}
}
