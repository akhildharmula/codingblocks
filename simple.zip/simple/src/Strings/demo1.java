package Strings;

public class demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="hello";
		String str1="hello";
		System.out.println(str1==str);
		String str3=new String("hello");
		System.out.println(str3==str1);
		String str4="hell";
		String str5=str4+"o";
		System.out.println(str5==str);
		String str6="hell"+"o";
		System.out.println(str6.compareTo(str4));
		char arr[]= {'1','2','3','4','5'};
		System.out.println(arr);
		String s=arr.toString();
		System.out.println(s);

	}

}
