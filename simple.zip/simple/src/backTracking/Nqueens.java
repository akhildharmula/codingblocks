package backTracking;

public class Nqueens {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 4;
		char matrix[][] = new char[n][n];
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				matrix[i][j] = '.';
			}
		}
		boolean possible[][] = new boolean[n][n];
		printpossiblematrixs(matrix, possible, n, 0);

	}

	private static void printpossiblematrixs(char[][] matrix, boolean[][] check, int n, int row) {
		// TODO Auto-generated method stub
		if (n == 0) {
			for (int i = 0; i < matrix.length; i++) {
				for (int j = 0; j < matrix[i].length; j++) {
					System.out.print(matrix[i][j]);
				}
				System.out.println();
			}
			System.out.println();
			return;
		}
		if(row==matrix.length)
		{
			return;
		}

		for (int col = 0; col < matrix.length; col++) {
			if (isitsafe(check, row, col)) {
				check[row][col] = true;
				matrix[row][col] = 'Q';
				printpossiblematrixs(matrix, check, n - 1, row + 1);
				matrix[row][col] = '.';
				check[row][col] = false;
			}
		}
	}

	private static boolean isitsafe(boolean[][] check, int row, int col) {
		// TODO Auto-generated method stub
		
		for (int i = 0; i < check.length; i++) {
			if (check[i][col] == true) {
				return false;
			}
		}
		
		int m = row, n = col;
		while (n < check.length && m < check.length) {
			if (check[m][n] == true) {
				return false;
			}
			m++;
			n++;
		}
		
		m = row;
		n = col;
		while (n >= 0 && m >= 0) {
			if (check[m][n] == true) {
				return false;
			}
			m--;
			n--;
		}
		
		m = row;
		n = col;
		while (n < check.length && m >= 0) {
			if (check[m][n] == true) {
				return false;
			}
			m--;
			n++;
		}
		
		
		m = row;
		n = col;
		while (n >= 0 && m < check.length) {
			if (check[m][n] == true) {
				return false;
			}
			m++;
			n--;
		}
		
		return true;
		

	}

}
