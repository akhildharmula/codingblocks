package backTracking;

public class sudukosolver {
	public static boolean issafe(char[][] board,int row,int col,char value)
    {
        int roww=row-(row%3);
        int coll=col-(col%3);
        for(int i=roww;i<roww+3;i++)
        {
            for(int j=coll;j<coll+3;j++)
            {
                if(board[i][j]==value)
                {
                    return false;
                }
            }
        }
        for(int i=0;i<9;i++)
        {
            
                if(board[row][i]==value)
                {
                    return false;
                }
        }
        for(int i=0;i<9;i++)
        {
                if(board[i][col]==value)
                {
                    return false;
                }
        }
        return true;

    }
    public static void logic(char[][] board,int row,int col,char[][] ans)
    {
    	if(col>=9)
        {
            row++;
            col=0;
        }
        if(row>=9)
        {
            for(int i=0;i<9;i++)
            {
                for(int j=0;j<9;j++)
                {
                    ans[i][j]=board[i][j];
                }
            }
            return;
        }
        
            if(board[row][col]!='.')
            {
            	logic(board,row,col+1,ans);
            }
            else	
            {
            	for(int i=1;i<=9;i++)
                {
            	char a = Character.forDigit(i, 10);
                if(issafe(board,row,col,a))
                {
                   board[row][col]=a;
                   logic(board,row,col+1,ans);
                    board[row][col]='.';
                }
            }
            }
        return;
    }
    public static void solveSudoku(char[][] board) {
          char[][] ans=new char[9][9];
       logic(board,0,0,ans);
       for(int i=0;i<9;i++)
            {
                for(int j=0;j<9;j++)
                {
                    board[i][j]=ans[i][j];
                }
            }
       
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 char[][] board ={{'5','3','.','.','7','.','.','.','.'},
				          {'6','.','.','1','9','5','.','.','.'},
				          {'.','9','8','.','.','.','.','6','.'},
				          {'8','.','.','.','6','.','.','.','3'},
				          {'4','.','.','8','.','3','.','.','1'},
				          {'7','.','.','.','2','.','.','.','6'},
				          {'.','6','.','.','.','.','2','8','.'},
				          {'.','.','.','4','1','9','.','.','5'},
				          {'.','.','.','.','8','.','.','7','9'}};
		
		 solveSudoku(board);
		 for(int i=0;i<9;i++) {
			 for(int j=0;j<9;j++)
			 {
				 System.out.print(board[i][j]+" ");
			 }
			 System.out.println();
			 
		 }

	}

}
