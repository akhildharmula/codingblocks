package backTracking;

public class Palindromeicsubstring {
	public static boolean ispalindrome(String s) {
		int start = 0;
		int end = s.length() - 1;
		while (start < end) {
			if (s.charAt(start) != s.charAt(end)) {
				return false;
			}
			start++;
			end--;
		}
		return true;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "nitin";
		printpalindromessubstring(s, "");

	}

	private static void printpalindromessubstring(String s, String ans) {
		System.out.println(ans +" "+ s);
		if(s.length()==0)
		{
			return;
		}
		for(int i=1;i<s.length();i++)
		{
			printpalindromessubstring(s.substring(i,s.length()),ans+s.charAt(0));
			
		}

	}
}
