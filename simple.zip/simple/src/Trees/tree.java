package Trees;
import java.util.*;
public class tree {
	Scanner sc=new Scanner(System.in);
	public class node
	{
		int data;
		node left;
		node right;
	public node()
	{
		
	}
	public node(int val)
	{
		this.data=val;
	}
	}
	
	private node root;
	
	public tree()
	{
		this.root=createtree(this.root);
	}
	public tree(int arr[])
	{
		this.root=createtreelevelorder(this.root,arr);
	}
	public tree(int pre[],int in[])
	{
		this.root=createtreelevelorder(this.root,pre,in,0,in.length-1);
	}
	private int idx=-1;
	private node createtreelevelorder(node root, int[] pre, int[] in,int start,int end) {
		// TODO Auto-generated method stub
		if(idx>=pre.length-1 || start>end)
		{
			return null;
		}
		node nn=new node(pre[++idx]);
		int mid=search(pre[idx],in,start,end);
		nn.left=createtreelevelorder(nn.left,pre,in,start,mid-1);
		nn.right=createtreelevelorder(nn.right,pre,in,mid+1,end);
		return nn;
	}
	private int search(int val, int[] in,int start,int end) {
		// TODO Auto-generated method stub
		for(int i=start;i<=end;i++)
		{
			if(in[i]==val)
			{
				return i;
			}
		}
		
		return -1;
	}
	private node createtreelevelorder(node root, int[] arr) {
		// TODO Auto-generated method stub
		Queue<node> q=new LinkedList<>();
		int i=0;
		node nn=new node(arr[i]);
		i++;
		q.add(nn);
		while(!q.isEmpty() && i< arr.length)
		{
			node t=q.remove();
			if(arr[i]!=-1)
			{
				node temp=new node(arr[i]);
				t.left=temp;
				q.add(temp);
			}
			if(arr[i+1]!=-1)
			{
				node temp=new node(arr[i+1]);
				t.right=temp;
				q.add(temp);
			}
			i=i+2;
		}
		
		return nn;
	}
	private node createtree(node root) {
		// TODO Auto-generated method stub
		int data=sc.nextInt();
		node nn=new node(data);
		
		boolean hlc =sc.nextBoolean();
		if(hlc)
		{
			nn.left=createtree(nn);
		}
		boolean hrc =sc.nextBoolean();
		if(hrc)
		{
			nn.right=createtree(nn);
		}
		return nn;
	}
	
	public void display()
	{
		display(this.root);
	}

	private void display(node root) {
		// TODO Auto-generated method stub
		if(root==null)
		{
			return;
		}
		String str="";
		str=str+root.data;
		if(root.left!=null)
		{
			str= root.left.data + "<--" +str;
		}
		else
		{
			str=  ".<--" +str;
		}
		if(root.right!=null)
		{
			str= str+"-->"+root.right.data;
		}
		else
		{
			str= str+"-->.";
		}
		System.out.println(str);
		display(root.left);
		display(root.right);
		
	}
	
	public int minimum()
	{
		return minimum(this.root);
	}
	/*
	 
	10
	true
	20
	true
	30
	false
	false
	false
	true
	40
	true
	50
	false
	false
	true
	6
	true
	70
	false
	false
	false  
	   
	   */

	private int minimum(node root) {
		// TODO Auto-generated method stub
		if(root==null)
		{
			return Integer.MAX_VALUE;
		}
		return Math.min(root.data,Math.min(minimum(root.left),minimum(root.right)));
	}
	public boolean find(int data)
	{
		return find(this.root,data);
	}

	private boolean find(node root, int d){
		// TODO Auto-generated method stub
		if(root==null)
		{
			return false;
		}
		if(root.data==d)
		{
			return true;
		}
		boolean temp=find(root.left,d);
		if(!temp)
			temp=find(root.right,d);
		return temp;
	}
	
	public int height()
	{
		return height(this.root,0);
	}

	private int height(node root,int h) {
		// TODO Auto-generated method stub
		if(root==null)
		{
			return h;
		}
		int a=height(root.left,h+1);
		int b=height(root.right,h+1);
		return Math.max(a, b);
	}
	public int diameter()
	{
		return diameter(this.root);
	}

	private int diameter(node root) {
		// TODO Auto-generated method stub
		if(root==null)
		{
			return -1;
		}
		int d=height(root.left,0)+height(root.right,0);
		int a=diameter(root.left);
		int b=diameter(root.right);
		return Math.max(d,Math.max(a,b));
	}
	public void preorder()
	{
		preorder(this.root);
	}

	private void preorder(node root) {
		// TODO Auto-generated method stub
		if(root==null)
		{
			return ;
		}
		System.out.print(root.data+" ");
		preorder(root.left);
		preorder(root.right);
		
	}
	public void inorder()
	{
		inorder(this.root);
	}

	private void inorder(node root) {
		// TODO Auto-generated method stub
		if(root==null)
		{
			return;
		}
		inorder(root.left);
		System.out.print(root.data+" ");
		inorder(root.right);
	}
	public void postorder()
	{
		postorder(this.root);
	}

	private void postorder(node root) {
		// TODO Auto-generated method stub
		if(root==null)
		{
			return;
		}
		postorder(root.left);
		postorder(root.right);
		System.out.print(root.data+" ");
		
	}
	public void levelorder()
	{
		levelorder(this.root);
	}

	private void levelorder(node root) {
		// TODO Auto-generated method stub
		Queue<node> q=new LinkedList<>();
		ArrayList<ArrayList<Integer>> ans=new ArrayList<>();
		q.add(root);
		while(!q.isEmpty())
		{
			ArrayList<Integer> li=new ArrayList<>();
			int size=q.size();
			int i=0;
			while(i<size)
			{
				node k=q.remove();
				li.add(k.data);
				if(k.left!=null)
				{
					q.add(k.left);
				}
				if(k.right!=null)
				{
					q.add(k.right);
				}
				i++;
			}
			ans.add(li);
		}
		System.out.println(ans);
	}
	
	public void zigzacorder()
	{
		zigzacorder(this.root);
	}

	private void zigzacorder(node root) {
		// TODO Auto-generated method stub
		Queue<node> q=new LinkedList<>();
		ArrayList<ArrayList<Integer>> ans=new ArrayList<>();
		q.add(root);
		int v=0;
		while(!q.isEmpty())
		{
			ArrayList<Integer> li=new ArrayList<>();
			int size=q.size();
			int i=0;
			while(i<size)
			{
				node k=q.remove();
				if(v%2!=0)
				li.add(0,k.data);
				else
				{
					li.add(k.data);
				}
				if(k.left!=null)
				{
					q.add(k.left);
				}
				if(k.right!=null)
				{
					q.add(k.right);
				}
				i++;
			}
			v++;
			ans.add(li);
		}
		System.out.println(ans);
		
	}
	public void boundaryorder()
	{
		List<Integer> ans=new ArrayList<>();
		boundaryorderleft(this.root,ans);
		ans.remove(ans.size()-1);
		boundaryorderleaf(this.root,ans);
		ans.add(1);
		boundaryorderright(this.root.right,ans,ans.size()-1);
		ans.remove(ans.size()-1);
		System.out.println(ans);
	}

	private void boundaryorderright(node root, List<Integer> ans,int index) {
		// TODO Auto-generated method stub
		if(root==null)
		{
			return;
		}
		ans.add(index,root.data);
	   boundaryorderright(root.right,ans,index);
	}

	private void boundaryorderleaf(node root, List<Integer> ans) {
		// TODO Auto-generated method stub
		if(root==null)
		{
			return;
		}
		if(root.left==null && root.right==null)
		{
			ans.add(root.data);
		}
		boundaryorderleaf(root.left,ans);
		boundaryorderleaf(root.right,ans);
	}

	private void boundaryorderleft(node root, List<Integer> ans) {
		// TODO Auto-generated method stub
		if(root==null)
		{
			return;
		}
		ans.add(root.data);
	   boundaryorderleft(root.left,ans);
	}
	

}
