package Trees;

public class treeclient {
	public static void main(String[] args) {
		tree bt=new tree();
//		bt.display();
//		System.out.println("Minimmum :"+bt.minimum());
//		System.out.println("present or not :"+bt.find(50));
//		System.out.println("Height :"+bt.height());
//		System.out.println("Diameter :"+bt.diameter());
//		System.out.println("preorder :");
//        bt.preorder();
//        System.out.println();
//        System.out.println("Inorder :");
//        bt.inorder();
//        System.out.println();
//        System.out.println("postorder :");
//        bt.postorder();
//        System.out.println()
//        System.out.println("levelorder :");
//        bt.levelorder();
//        System.out.println();
//        System.out.println("ZigZacorder :");
//        bt.zigzacorder();;
//        System.out.println();
        bt.boundaryorder();
//        int arr[]= {1,2,5,3,4,6,-1,-1,-1,7,8,-1,-1,-1,-1,-1,-1};
//        tree b=new tree(arr);
//        System.out.println("level order :");
//        b.levelorder();
//        System.out.println();
//        b.display();
//        
//        int pre[]= {1,2,4,5,8,3,6,7,9};
//        int in[]= {4,2,8,5,1,6,3,7,9};
//        tree b=new tree(pre,in);
//        System.out.println("preorder :");
//      b.preorder();
//      System.out.println();
//      System.out.println("Inorder :");
//      b.inorder();
//      System.out.println();
//      b.display();
        
	}

}
