package Graph;

import java.util.*;

public class graph {
	HashMap<Integer, HashMap<Integer, Integer>> map;

	public graph() {
		this.map = new HashMap<>();
	}

	public void addedge(Integer u, Integer v, int cost) {
		if (map.containsKey(u)) {
			map.get(u).put(v, cost);
		} else {
			map.put(u, new HashMap<>());
			map.get(u).put(v, cost);
		}

		if (map.containsKey(v)) {
			map.get(v).put(u, cost);
		} else {
			map.put(v, new HashMap<>());
			map.get(v).put(u, cost);
		}
	}

	public void display() {
		for (Integer u : map.keySet()) {
			System.out.println(u + "  " + map.get(u));
		}
	}

	public int noofedges() {
		int size = 0;
		for (Integer u : map.keySet()) {
			size += map.get(u).size();
		}
		return size / 2;
	}

	public void addvertex(int n) {
		if (!map.containsKey(n)) {
			map.put(n, new HashMap<>());
		}
	}

	public void removeedge(int v1, int v2) {
		map.get(v1).remove(v2);
		map.get(v2).remove(v1);
	}

	public void removevertex(int n) {
		map.remove(n);
		for (Integer u : map.keySet()) {
			map.get(u).remove(n);
		}
	}

	public boolean containsedge(int v1, int v2) {
		return map.get(v1).containsKey(v2);
	}

	public boolean Containsvertex(int v) {
		return map.containsKey(v);
	}

	public boolean haspath(int src, int dst) {
		HashSet<Integer> set = new HashSet<>();
		set.add(src);
		return haspath(src, dst, set);
	}

	private boolean haspath(int src, int dst, HashSet<Integer> set) {
		if (src == dst) {
			return true;
		}
		boolean ans = false;
		if (map.containsKey(src)) {
			for (int k : map.get(src).keySet()) {
				if (!set.contains(k) && !ans) {
					set.add(k);
					ans = haspath(k, dst, set);
				}
			}
		}
		return ans;
	}

	public void printpaths(int src, int dst) {
		HashSet<Integer> set = new HashSet<>();
		set.add(src);
		printpaths(src, dst, set, "" + src);
	}

	private void printpaths(int src, int dst, HashSet<Integer> set, String s) {
		if (src == dst) {
			System.out.println(s);
		}
		if (map.containsKey(src)) {
			for (int k : map.get(src).keySet()) {
				if (!set.contains(k)) {
					set.add(k);
					printpaths(k, dst, set, s + k);
					set.remove(k);
				}
			}
		}
		return;
	}

	public void bfs(int startvertex) {
		ArrayList<Integer> vistedset=new ArrayList<>();
		Queue<Integer> q=new LinkedList<>();
		q.add(startvertex);
		while(!q.isEmpty())
		{
			int t=q.remove();
			if(vistedset.contains(t))
				continue;
			vistedset.add(t);
			for(int k:map.get(t).keySet())
			{
				if(!vistedset.contains(k))
					q.add(k);
			}
		}
		System.out.println("bfs: " +vistedset);
		
	}
	public void dfs(int startvertex) {
		ArrayList<Integer> vistedset=new ArrayList<>();
		Stack<Integer> st=new Stack<>();
		st.push(startvertex);
		while(!st.isEmpty())
		{
			int t=st.pop();
			if(vistedset.contains(t))
				continue;
			vistedset.add(t);
			for(int k:map.get(t).keySet())
			{
				if(!vistedset.contains(k))
					st.push(k);
			}
		}
		System.out.println("dfs: " +vistedset);
		
	}

	public boolean hasCycle(int startvertex)
	{
		ArrayList<Integer> vistedset=new ArrayList<>();
		Queue<Integer> q=new LinkedList<>();
		q.add(startvertex);
		while(!q.isEmpty())
		{
			int t=q.remove();
			if(vistedset.contains(t))
				return true;
			vistedset.add(t);
			for(int k:map.get(t).keySet())
			{
				if(!vistedset.contains(k))
					q.add(k);
			}
		}
		return false;
	}

}
