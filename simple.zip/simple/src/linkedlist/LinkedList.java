package linkedlist;

public class LinkedList {
	private class Node
	{
		int data;
		Node next;
	}
	Node Head;
	Node Tail;
	int size;
	public void insertdataatfirst(int val) {
		Node newnode=new Node();
		newnode.data=val;
		if(size==0)
		{
			Tail=newnode;
		}
		else
		{
			newnode.next=Head;
		}
		Head=newnode;
		size++;
	}
	public void insertdataatlast(int val)
	{
		Node newnode=new Node();
		newnode.data=val;
		if(size!=0)
		{
			Tail.next=newnode;
			Tail=newnode;
			size++;
		}
		else
		{
			insertdataatfirst(val);
		}
	}
	public void insertatindex(int val,int idx)
	{
		if(idx==0)
		{
			insertdataatfirst(val);
		}
		else
		{
			if(idx==size)
			{
				insertdataatlast(val);
			}
			else
			{
				Node newnode=new Node();
				newnode.data=val;
				Node temp=getNode(idx-1);
				Node temp2=temp.next;
				temp.next=newnode;
				newnode.next=temp2;
				size++;
			}
		}
	}
	public Node getNode(int idx)
	{
		Node temp=Head;
		for(int i=1;i<=idx;i++)
		{
			temp=temp.next;
		}
		return temp;
	}
	public int getFirst()throws Exception
	{
		if(size!=0)
		return Head.data;
		throw new Exception("linked list is empty");
	}
	public int getLast() throws Exception
	{
		if(size!=0)
		return Tail.data;
		throw new Exception("Linked list is empty");
	}
	public int size()
	{
		return size;
	}
	public void removeFirst()throws Exception
	{
		if(size!=0)
		{
		   Node temp=Head;
		   Head=Head.next;
		   temp.next=null;
		   size--;
		   return;
		}
		throw new Exception("Linked List is Empty");
		
	}
	public void removeLast()throws Exception
	{
		if(size!=0)
		{
		   Node temp=getNode(size-1);
		   temp.next=null;
		   size--;
		   return;
		}
		throw new Exception("Linked List is Empty");
		
	}
	
	public void removeKthNode(int k)throws Exception
	{
		if(size!=0)
		{
		   Node temp=getNode(k-1);
		   temp.next=temp.next.next;
		   temp.next.next=null;
		   size--;
		   return;
		}
		throw new Exception("Linked List is Empty");
		
	}
	public boolean isempty()
	{
		return size==0;
	}
	public void display()throws Exception
	{
		if(size!=0)
		{
		   Node temp=Head;
		   while(temp!=null)
		   {
			   System.out.print(temp.data+" ");
			   temp=temp.next;
		   }
		   return;
		}
		throw new Exception("Linked List is Empty");
		
	}
	public void ajayaccenture()
	{
		if(Head==null)
		{
			return;
		}
		Node temp=Head;
		Node ttemp =null;
		if(temp.next!=null && temp.next.next!=null)
		{
		   ttemp=temp.next.next;
		}
		while(ttemp!=null)
		{
			   ttemp.data=temp.data+ttemp.data;
			   temp=temp.next;
			   ttemp=ttemp.next;
		}
		
	}
	
	

}
