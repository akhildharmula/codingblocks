package bitmasking;

public class subsequence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="abc";
		int n=(int)Math.pow(2,s.length());
		System.out.println(n);
       for(int i=0;i<n;i++)
       {
    	   String res="";
    	   int d=i;
    	   int k=0;
    	   while( d!=0)
    	   {
    		   if((d&1)==1)
    		   {
    			   res+=s.charAt(k);
    		   }
    		   d>>=1;
    		   k++;
    	   }
    	   System.out.println(res);
       }
	}

}
