package bitmasking;

public class setbitatpostoone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=9;
		int pos=3;
		int mask=1;
		mask<<=pos;
		n^=mask;
		System.out.println(n);

	}

}
