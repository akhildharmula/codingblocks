/**
 * 
 */
/**
 * @author AKHIL
 *
 */
module simple {
}