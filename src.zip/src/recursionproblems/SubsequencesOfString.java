package recursionproblems;

public class SubsequencesOfString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            String s="abc";
            subsequences(s,"");
	}

	private static void subsequences(String s,String ans) {
		// TODO Auto-generated method stub
		if(s.length()==0)
		{
			System.out.println(ans);
			return;
		}
		subsequences(s.substring(1),ans+s.charAt(0));
		subsequences(s.substring(1),ans);
	}

}
