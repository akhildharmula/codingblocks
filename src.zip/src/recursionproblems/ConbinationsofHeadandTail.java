package recursionproblems;

public class ConbinationsofHeadandTail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 3;
		combinations("", n);
	}

	private static void combinations(String s, int n) {

		// TODO Auto-generated method stub
		if (n == 0) {
			System.out.println(s);
			return;
		}
		if(s.length()!=0&&s.charAt(s.length()-1)=='H')
		{
			combinations(s + "T", n - 1);
		}
		else
		{
			if(s.length()!=0&&s.charAt(s.length()-1)=='T')
			combinations(s + "H", n - 1);
			else
			{
				combinations(s + "H", n - 1);
				combinations(s + "T", n - 1);
			}
		}
	}

}
