package recursionproblems;

public class PrintPathsGrid {
   static int count=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=3;
		int m=3;
		logic(0,0,n,m,"");

	}

	private static void logic(int i,int j,int n, int m, String ans) {
		// TODO Auto-generated method stub
		if(i==n-1 && j==m-1)
		{
			System.out.println(ans);
			return;
		}
		if(i>=n || j>=m)
		{
			return;
		}
		logic(i+1,j,n,m,ans+"H");
		logic(i,j+1,n,m,ans+"V");
			
		}
		
	
}


