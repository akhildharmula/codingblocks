package recursionproblems;

public class ReplacePi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="abpicpidp";
		logic(s,"");

	}

	private static void logic(String s, String ans) {
		
		// TODO Auto-generated method stub
		if(s.length()==0)
		{
			System.out.println(ans);
			return;
		}
		if(s.length()>1&&s.charAt(0)=='p'&&s.charAt(1)=='i')
		{
			logic(s.substring(2),ans+"3.14");
		}
		else
		{
			logic(s.substring(1),ans+s.charAt(0));
		}
	}

}
