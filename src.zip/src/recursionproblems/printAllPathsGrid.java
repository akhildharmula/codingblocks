package recursionproblems;

public class printAllPathsGrid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int vis[][]=new int[3][3];
           print(0,0,3,3,"",vis);
	}

	private static void print(int i, int j, int n, int m, String ans,int[][] vis) {
		// TODO Auto-generated method stub
		if(i==n-1 && j==m-1)
		{
			System.out.println(ans);
			return;
		}
		if(i<0 || i>=n || j<0 || j>=m || vis[i][j]==1)
		{
			return;
		}
		vis[i][j]=1;
		print(i-1,j,n,m,ans+"T",vis);
		print(i,j-1,n,m,ans+"L",vis);
		print(i+1,j,n,m,ans+"D",vis);
		print(i,j+1,n,m,ans+"R",vis);
		vis[i][j]=0;
		
	}

}
