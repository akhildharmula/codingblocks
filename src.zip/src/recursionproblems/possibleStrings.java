package recursionproblems;
import java.util.*;
public class possibleStrings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           String s="125";
           List<String> l=new ArrayList<>();
           logic(s,l,"");
           System.out.println(l);
	}

	private static void logic(String s, List<String> fi,String ans) {
		// TODO Auto-generated method stub
		if(s.length()==0)
		{
			fi.add(ans);
			return;
		}
		
		logic(s.substring(1),fi,ans+(char)(Integer.parseInt(s.charAt(0)+"")+96));
		if(s.length()>=2)
		{
			int n=Integer.parseInt(s.substring(0,2));
			if(n<=26)
			{
				logic(s.substring(2),fi,ans+(char)(n+96));
			}
		}
	
		
	}
	
	

}
