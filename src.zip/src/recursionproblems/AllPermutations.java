package recursionproblems;

public class AllPermutations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "1232";
		PrintPermutations(s, "");

	}

	private static void PrintPermutations(String s, String ans) {
		// TODO Auto-generated method stub
		if (s.length() == 0) {
			System.out.println(ans);
			return;
		}
		for (int i = 0; i < s.length(); i++) {
			if (s.indexOf(s.charAt(i)) >= i)
				PrintPermutations(s.substring(0,i) + s.substring(i + 1, s.length()), ans + s.charAt(i));
		}

	}

}
