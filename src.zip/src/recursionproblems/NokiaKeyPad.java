package recursionproblems;

public class NokiaKeyPad {
	static String[] str= {"","","abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     String s="22222";
     //Print(s,"");
     print1(s,"");
	}
	private static void print1(String s, String ans) {
		// TODO Auto-generated method stub
		if(s.length()==0)
		{
			System.out.println(ans);
			return;
		}
		String s1=str[s.charAt(0)-48];
		int v=0;
		while(v<s.length()-1&&s.charAt(v)==s.charAt(v+1))
		{
			v++;
		}
		v++;
		System.out.print(v+" ");
		v=v%s1.length();
		System.out.println(v);
		print1(s.substring(v+1),ans+s1.charAt(v));
		
	}
	private static void Print(String s, String ans) {
		// TODO Auto-generated method stub
		if(s.length()==0)
		{
			System.out.println(ans);
			return;
		}
		String s1=str[s.charAt(0)-48];
		for(int i=0;i<s1.length();i++)
		{
			
			Print(s.substring(1),ans+s1.charAt(i));
		}
		
	}
	

}
