package recursionproblems;

public class possibleBraces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=4;
		printbraces(n,0,0,"");
		System.out.println("Total Number of ways: "+ count(n,0,0));
	}

	private static int count(int n, int n1, int n2) {
		// TODO Auto-generated method stub
		int a=0,b=0;
		if(n1==n && n2==n)
		{
			return 1;
		}
		if(n1<n)
		{
			a=count(n,n1+1,n2);
		}
		if(n2<n1){
			b=count(n,n1,n2+1);
		}
		return a+b;
	}

	private static void printbraces(int n,int n1,int n2, String ans) {
		// TODO Auto-generated method stub
		if(n1==n && n2==n)
		{
			System.out.println(ans);
			
			return;
		}
		if(n1<n)
		{
			printbraces(n,n1+1,n2,ans+"(");
		}
		if(n2<n1){
			printbraces(n,n1,n2+1,ans+")");
		}
	}

}
