package Arrays;

import java.util.*;

public class Aggressivecows {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int c = sc.nextInt();
		int a[] = new int[n];
		
		for (int i = 0; i < n; i++) {
			a[i] = sc.nextInt();
		}
		Arrays.sort(a);
		int count = minimumdistance(a, c);
		System.out.println(count);
		sc.close();
	}
     
	private static int minimumdistance(int[] a, int c) {
		// TODO Auto-generated method stub
		int ans = 0;
		int start = a[0];
		int end = a[a.length - 1];
		while (start <= end) {
			int mid = start + (end - start) / 2;
			if (isitpossible(a, c, mid)) {
				ans = mid;
				start = mid + 1;
			} else {
				end = mid - 1;
			}

		}
		return ans;
	}

	private static boolean isitpossible(int[] a, int c, int mid) {
		// TODO Auto-generated method stub
		int cowplaced = 1;
		int lastplaced = a[0];
		for (int i = 1; i < a.length; i++) {
			if ((a[i] - lastplaced) >= mid) {
				cowplaced++;
				lastplaced = a[i];
			}
		}
		if (cowplaced >= c) {
			return true;
		}
		return false;
	}

}
