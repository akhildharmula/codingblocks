package Arrays;

public class ApowerB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int b = 3;
		int a=10;
		System.out.println(pow(a,b));

	}

	private static int pow(int a,int b) {
		// TODO Auto-generated method stub
		if(b==0)
		{
			return 1;
		}
		return a*(pow(a,b-1));
	}

}
