package Arrays;
import java.util.*;
public class Painters {
	public static int maxx(int[] arr,int start,int end)
    {
        int max=0;
        for(int i=start;i<=end;i++)
        {
            if(arr[i]>=max)
            {
                max=arr[i];
            }
        }
        return max;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
        int k=sc.nextInt();
        int n=sc.nextInt();
        int b[]=new int[n];
        for(int i=0;i<n;i++)
        {
           b[i]=sc.nextInt();
        }
        sc.close();
        int t=0;
        int start=0,end=0;
        while(start<n)
        {
             end=end+k;
             if(end>=n)
             {
                 end=n-1;
             }
              t=t+maxx(b,start,end);
              start=end+1;
        }
        System.out.println(t);

	}

}
