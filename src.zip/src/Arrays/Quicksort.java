package Arrays;

public class Quicksort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] arr= {5,4,3,10,11,2,1};
		quicksort(arr,0,arr.length-1);
		for(int k:arr)
		{
			System.out.print(k+" ");
		}

	}

	private static void quicksort(int[] arr, int start, int end) {
		// TODO Auto-generated method stub
		if(start>end)
		{
			return;
		}
		int pi=findpivot(arr,start,end);
		quicksort(arr,start,pi-1);
		quicksort(arr,pi+1,end);
		
	}

	private static int findpivot(int[] arr, int start, int end) {
		// TODO Auto-generated method stub
		int pivot=end;
		int pi=start;
		for(int i=start;i<end;i++)
		{
			if(arr[i]<=arr[pivot])
			{
				int temp=arr[i];
				arr[i]=arr[pi];
				arr[pi]=temp;
				pi++;
			}
		}
		int temp=arr[pi];
		arr[pi]=arr[end];
		arr[end]=temp;
		
		return pi;
	}

}
