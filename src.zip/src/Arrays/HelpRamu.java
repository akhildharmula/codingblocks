package Arrays;
import java.util.*;
public class HelpRamu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int tickets[]=new int[4];
		for(int i=0;i<4;i++)
		{
			tickets[i]=sc.nextInt();
		}
		int n=sc.nextInt();
		int m=sc.nextInt();
		int rickshaws[]=new int[n];
		int cabs[]=new int[m];
		for(int i=0;i<n;i++)
		{
			rickshaws[i]=sc.nextInt();
		}
		for(int i=0;i<m;i++)
		{
			cabs[i]=sc.nextInt();
		}
       int costr=0;
       for(int i=0;i<n;i++)
       {
    	   costr+=(Math.min(rickshaws[i]*tickets[0],tickets[1]));
       }
       costr=Math.min(costr,tickets[2]);
       int costc=0;
       for(int i=0;i<m;i++)
       {
    	   costc+=(Math.min(cabs[i]*tickets[0],tickets[1]));
       }
       costc=Math.min(costc,tickets[2]);
       int ans=costc+costr;
       ans=Math.min(ans,tickets[3]);
       System.out.println(ans);
       sc.close();

	}

}
