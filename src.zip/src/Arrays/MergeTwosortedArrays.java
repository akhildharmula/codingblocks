package Arrays;

public class MergeTwosortedArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int first[]= {5,5,5,11,15,17};
		int second[]= {5,6,9,14,21};
		int third[]=new int[first.length+second.length];
		int i=0,j=0,k=0;
		while(i<first.length && j<second.length)
		{
			if(first[i]<second[j]){
				third[k]=first[i];
				i++;
			}
			else
			{
				third[k]=second[j];
				j++;
			}
			k++;
		}
		while(i<first.length)
		{
			third[k]=first[i];
			i++;
			k++;
		}
		while(j<second.length)
		{
			third[k]=second[j];
			j++;
			k++;
		}
		for(int g:third)
		{
			System.out.println(g);
		}
		

	}

}
