package Arrays;
import java.util.*;
public class Maximumsumpathtwoarrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            Scanner sc=new Scanner(System.in);
            int n=sc.nextInt();
            int m=sc.nextInt();
            int arr[]=new int[n];
            int brr[]=new int[m];
            for(int i=0;i<n;i++)
            {
            	arr[i]=sc.nextInt();
            }
            for(int j=0;j<m;j++)
            {
            	brr[j]=sc.nextInt();
            }
            sc.close();
            System.out.println(maxsum(arr,brr,n,m));
	}

	private static int maxsum(int[] arr, int[] brr, int n, int m) {
		// TODO Auto-generated method stub
		int ans=0;
		int i=0,j=0,sum1=0,sum2=0;
		while(i<n&&j<m)
		{
			if(arr[i]<brr[j])
			{
				sum1+=arr[i];
				i++;
			}
			else
			{
				if(arr[i]>brr[j])
				{
					sum2+=brr[j];
					j++;
				}
				else
				{
					ans+=arr[i];
					ans+=Math.max(sum1, sum2);
					sum1=0;
					sum2=0;
					i++;
					j++;
				}
			}
		}
		sum1=0;
		sum2=0;
		while(i<n)
		{
			sum1+=arr[i];
			i++;
		}
		while(j<m)
		{
			sum2+=brr[j];
			j++;
		}
		ans+=Math.max(sum1, sum2);
		return ans;
	}
	

}
