package Arrays;

import java.util.Scanner;

public class Maximum_sub_array_sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter the Elements array");
		for (int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		sc.close();
		int ele=subArraysum(arr);
		int ele1=subArraysumsecondmethod(arr);
		int ele2=subArraysumkadenesalogo(arr);
		System.out.println(ele);
		System.out.println(ele1);
		System.out.println(ele2);
	}

	private static int subArraysumkadenesalogo(int[] arr) {
		// TODO Auto-generated method stub
		int ans=Integer.MIN_VALUE;
		int sum=0;
		for(int i=0;i<arr.length;i++)
		{
			sum+=arr[i];
			ans=Math.max(ans, sum);
			if(sum<0)
			{
				sum=0;
			}
		}
		
		
		return ans;
	}

	private static int subArraysumsecondmethod(int[] arr) {
		// TODO Auto-generated method stub
		int ans=0;
		for(int i=0;i<arr.length;i++)
		{
			int sum=0;
			for(int j=i;j<arr.length;j++)
			{
				sum+=arr[j];
				ans=Math.max(ans, sum);
			}
		}
		return ans;
	}

	private static int subArraysum(int[] arr) {
		// TODO Auto-generated method stub
		int ans=0;
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i;j<arr.length;j++)
			{
				int sum=0;
				for(int k=i;k<=j;k++)
				{
					sum=sum+arr[k];
				}
				ans=Math.max(ans, sum);
			}
		}
		return ans;
	}

}
