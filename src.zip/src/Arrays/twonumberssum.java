package Arrays;

import java.util.ArrayList;

public class twonumberssum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int a[]= {9,2,3,9,9,9};
        int b[]= {9,9,2};
        ArrayList<Integer> ans=new ArrayList<>();
        
        int i=a.length-1;
        int j=b.length-1;
        int carry=0;
        while(i>=0 || j>=0)
        {
        	int sum=carry;
        	if(i>=0)
        	{
        		sum+=a[i];
        		i--;
        	}
        	if(j>=0)
        	{
        		sum+=b[j];
        		j--;
        	}
        	carry=sum/10;
        	ans.add(0,sum%10);
        }
        if(carry>=1)
        {
        	ans.add(0,carry);
        }
        System.out.println(ans);
        
	}

}