package Arrays;

import java.util.Scanner;

public class MaxCircularSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int n = sc.nextInt();
		int arr[] = new int[n];
		System.out.println("Enter the Elements array");
		for (int i = 0; i < n; i++) {
			arr[i] = sc.nextInt();
		}
		sc.close();
		int ele=maxcircularsum(arr);
		System.out.println(ele);
		

	}

	private static int maxcircularsum(int[] arr) {
		// TODO Auto-generated method stub
		int csum=Integer.MIN_VALUE;
		for(int i=0;i<arr.length;i++)
		{
			int sum=0;
		    int maxsum=Integer.MIN_VALUE;
		    int j;
			if(i!=arr.length-1)
			{
				 j=i+1;
			}
			else
			{
				j=0;
			}
			while(j!=i)
			{
				sum+=arr[j];
				maxsum=Math.max(maxsum, sum);
				if(sum<0)
				{
					sum=0;
				}
				if(j==arr.length-1)
				{
					j=0;
				}
				else
				{
					j++;
				}
				
			}
			
			if(maxsum>csum)
			{
				csum=maxsum;
			}
		
		}
		return csum;
	}

}
