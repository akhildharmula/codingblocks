package Queue;

public class test {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		queue q=new queue();
		q.enqueue(10);
		q.enqueue(20);
		q.enqueue(30);
		q.enqueue(40);
		q.enqueue(50);
		q.dequeue();
		q.enqueue(60);
		System.out.println("display : ");
		q.display();
		q.dequeue();
		q.dequeue();
		q.enqueue(70);
		System.out.println("display : ");
		q.display();

	}

}
