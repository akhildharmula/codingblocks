package Queue;

public class queue {
	int data[];
	int front;
	int size;
	public queue()
	{
	  data=new int[5];
	  front=0;
	  size=0;
	}
	public queue(int size)
	{
	  data=new int[size];
	  front=0;
	  size=0;
	}
	public boolean isempty()
	{
		return size==0;
	}
	public boolean isfull()
	{
		return size==data.length;
	}
	public int size()
	{
		return size;
	}
	public void enqueue(int val)throws Exception
	{
		if(!isfull())
		{
			int idx=(front+size)%data.length;
			data[idx]=val;
			size++;
			return;
		}
		throw new Exception ("Queue is full");
	}
	public int dequeue()throws Exception
	{
		if(!isempty())
		{    int val=data[front];
			front=(front+1)%data.length;
			size--;
			return val;
		}
		throw new Exception ("Queue is empty");
	}
	public void display()throws Exception
	{
		if(!isempty())
		{
			int t=front;
			for(int i=0;i<size;i++)
			{
				System.out.println(data[t]+" ");
				t++;
				if(t==data.length)
				{
					t=0;
				}
			}
			return;
		}
		throw new Exception ("Queue is empty");
	}
	
	

}
