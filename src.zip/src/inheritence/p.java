package inheritence;

public class p {

	int d=1;
	int dp=10;
	
	public void fun()
	{
		System.out.println("Fun inside Parent Class");
	}
	
	public void funparent()
	{
		System.out.println("Funparent inside Parent Class");
	}

}
