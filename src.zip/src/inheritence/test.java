package inheritence;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// case 1
		
		p obj1=new p();
		System.out.println(obj1.d);
		System.out.println(obj1.dp);
		
		obj1.fun();
		obj1.funparent();
		
		System.out.println("----------------------------------");
		
		// case 2
		
		p obj2=new c();
		System.out.println(obj2.d);
		System.out.println(obj2.dp);
		
		obj2.fun();
		obj2.funparent();
		
		
        System.out.println("----------------------------------");
		
		// case 3  NOT possible IN JAVA
        
        System.out.println("case 3  NOT possible IN JAVA");
		
//		c obj3=new p();
//		
//		System.out.println(obj3.d);
//		System.out.println(obj3.dc);
//		
//		obj3.fun();
//		obj3.funchild();
        
        System.out.println("----------------------------------");
		
		//case 4
		
        c obj4=new c();
		
		System.out.println(obj4.d);
		System.out.println(obj4.dc);
		
		obj4.fun();
		obj4.funchild();
		
		System.out.println(((p)obj4).d);
		System.out.println(obj4.dp);
		
		obj4.fun();
		obj4.funparent();
		
		
		
		
		

	}

}
