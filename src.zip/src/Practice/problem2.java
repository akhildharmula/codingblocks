package Practice;

public class problem2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] s= {"D","I","DD","II"};
		for(int i=0;i<s.length;i++)
		{
			int j=1;
			String ans=""+j;
			while(s[i].length()!=0)
			{
				if(s[i].charAt(0)=='D')
				{
					j++;
					ans=j+ans;
				}
				else
				{
					j++;
					ans=ans+j;
				}
				s[i]=s[i].substring(1);
			}
			System.out.println(ans);
			
		}

	}

}
