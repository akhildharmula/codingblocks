package Practice;

public class problem1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] s= {"54","546","548","60"};
		String ans="";
		for(int i=0;i<s.length;i++)
		{
			int t=ans.compareTo(s[i]);
			if(t>0)
			{
				ans=ans+s[i];
			}
			else
			{
				ans=s[i]+ans;
			}
		}
		System.out.println(ans);
		

	}

}
