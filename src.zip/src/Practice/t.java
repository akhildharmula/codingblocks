package Practice;

public class t {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          int sum=11;
          int [] primes= {2,3,5};
          int c=0,i=2;
          while(sum>0 && i>=0)
          {
        	  while(sum>=primes[i])
        	  {
        		  sum-=primes[i];
        		  c++;
        	  }
        	  i--;
          }
          if(sum>0)
          {
        	  System.out.println("-1");
          }
          else
          {
        	  System.out.println(c);
          }
          
          
	}

}
