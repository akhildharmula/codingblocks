package Stack;

public class Dystack extends stack{

	public void push(int ele) throws Exception
	{
		if(isfull())
		{
			int newdata[]=new int[data.length*2];
			for(int i=0;i<data.length;i++)
			{
				newdata[i]=data[i];
			}
			data=newdata;
		}
			super.push(ele);
	}

}
