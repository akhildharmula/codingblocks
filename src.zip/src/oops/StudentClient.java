package oops;

public class StudentClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s=new Student();
		s.age=21;
		s.name="akhil";
		Student s1=new Student();
		s1.age=22;
		s1.name="akhil Dharmula";
		s.intro();
		s1.intro();
		

	}

}
