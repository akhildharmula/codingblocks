package simple;

import java.util.Scanner;

public class deloitteexamquestion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		int y = sc.nextInt();
		int t=logic(x,y);
		System.out.println(t);
		sc.close();
	}

	private static int logic(int x, int y) {
		// TODO Auto-generated method stub
		int mul=10;
		int i=0;
		int n=x;
		while(x%y!=0)
		{
			x=(n*mul)+i;
			if(i>9 )
			{
				mul=100;
			}
			else if(i>=10&&i<=99) {
				mul=1000;
			}
			i++;
		}
		return x;
	}

}
