package simple;
import java.util.*;
public class Greatestofthethreenumbers {

	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first Number");
		int a=sc.nextInt();
		System.out.println("Enter the second Number");
		int b=sc.nextInt();
		System.out.println("Enter the third Number");
		int c=sc.nextInt();
		if(a>b)
		{
			if(a>c)
			{
				System.out.println(a+" is a Greatest Number");
			}
			else
			{
				System.out.println(c+" is a Greatest Number");
			}
		}
		else
		{
			if(a>b)
			{
				System.out.println(a+" is a Greatest Number");
			}
			else
			{
				System.out.println(b+" is a Greatest Number");
			}
		}
		sc.close();

	}
}
