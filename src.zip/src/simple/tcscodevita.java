package simple;
import java.util.*;
public class tcscodevita {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	    int n = sc.nextInt();
	    int[] a = new int[n];
	    int b[]=new int[n];
	    for(int i=0;i<n;i++)
	    {
	    	a[i] = sc.nextInt();
	    	b[i]=a[i];
	    }
	    
	    Arrays.sort(a);
	    
	    int count1=0;
	    for(int i=0;i<n;i++)
	    {
	    	if(a[i]!=b[i])
	    	{
	    		count1++;
	    	}
	    }
	    int count2=0;
	    for(int i=n-1,j=0;i>=0;i--,j++)
	    {
	    	if(a[i]!=b[j])
	    	{
	    		count2++;
	    	}
	    }
	    System.out.println(Math.min(count1,count2));
	
	}
}

