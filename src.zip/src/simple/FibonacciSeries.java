package simple;
import java.util.*;
public class FibonacciSeries {
	public static int fibonaccisecondmethod(int n)
    {
    	if(n==1)
    	{
    		return 0;
    	}
    	if(n==2)
    	{
    		return 1;
    	}
    	return fibonaccisecondmethod(n-1)+fibonaccisecondmethod(n-2);
    }
	public static void fibonaccifirstmethod(int n)
    {
    	
    	int c=0;
    	int a=0,b=1;
    	for(int i=0;i<n;i++)
    	{
    		System.out.print(c+" ");
    		c=a+b;
    		b=a;
    		a=c;
    	}
    }
	public static void fibdp(int n,int[] dp)
	{
		if(n==0 || n==1)
		{
			dp[n]=n;
			return;
		}
		if(dp[n-1]==-1)
		{
			fibdp(n-1,dp);
		}
		if(dp[n-2]==-1)
		{
			fibdp(n-2,dp);
		}
		
		dp[n]=dp[n-1]+dp[n-2];
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter number");
    int n=sc.nextInt(); 
    int arr[]=new int[n];
    arr[0]=0;
    arr[1]=1;
    for(int i=2;i<n;i++)
    {
    	arr[i]=arr[i-1]+arr[i-2];
    }
    for(int k:arr)
    {
    	System.out.print(k+" ");
    }
    System.out.println();
    for(int i=1;i<=n;i++)
	{
    	System.out.print(fibonaccisecondmethod(i)+" ");
	}
    System.out.println();
    int dp[]=new int[n];
    Arrays.fill(dp,-1);
    fibdp(n-1,dp);
    for(int k:dp)
    {
    	System.out.print(k+" ");
    }
    
     sc.close();
	}

}
