package simple;
import java.util.*;
public class Sumofoddplaceddigitsandeven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner sc=new Scanner(System.in);
   System.out.println("Enter the Number");
   int n=sc.nextInt();
   sc.close();
   int esum=0;
   int osum=0;
   int rev=0;
   while(n!=0)
   {  int t=n%10;
	   rev=rev*10+t;
	   n=n/10;
   }
   int k=1;
   while(rev!=0)
   {
	  int t=rev%10;
	  if(k%2==0)
	  {
		  esum=esum+t;
	  }
	  else
	  {
		  osum=osum+t;
	  }
	  rev=rev/10;
	  k++;
   }
   System.out.println(esum+" Even placed digits sum");
   System.out.println(osum+" Odd placed digits sum");
	}

}
