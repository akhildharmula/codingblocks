package simple;

public class ajayaccenture {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="DCCBAA";
		int sum=0;
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)=='A')
			{
				sum=sum+1;
			}
			else
			{
				if(s.charAt(i)=='B')
				{
					sum=sum+10;	
				}
				else
				{
					if(s.charAt(i)=='C')
					{
						sum=sum+100;
					}
					else
					{
						if(s.charAt(i)=='D')
						{
							sum=sum+1000;
						}
						else
						{
							if(s.charAt(i)=='E')
							{
								sum=sum+10000;	
							}
							else
							{
								if(s.charAt(i)=='F')
								{
									sum=sum+100000;
								}
								else
								{
									if(s.charAt(i)=='G')
									{
										sum=sum+1000000;
									}
									else
									{
										sum=sum+0;
									}
								}
							}
						}
					}
				}
			}
		}
		System.out.println(sum);

	}

}
