package simple;

public class Primeseive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=51;
		boolean[] arr=new boolean[51];
		for(int i=2;i*i<n;i++)
		{
			for(int mul=i+i;mul<n;mul=mul+i)
			{
				if(!arr[mul])
				{
					arr[mul]=true;
				}
			}
		}
		for(int i=2;i<n;i++)
		{
			if(!arr[i])
			{
				System.out.println(i);
			}
		}
		

	}

}
