package simple;
import java.util.*;
public class Gcd {
	public static int gcdsecondmethod(int divident,int divisor) {
    	while((divident%divisor)!=0)
    	{
    		int rem=divident%divisor;
    		divident=divisor;
    		divisor=rem;
    	}
    	
    	return divisor;
    }
    public static int gcd(int n,int m) {
    	if(n<m)
    	{
    		int t=n;
    		n=m;
    		m=t;	
    	}
    	if(m==0)
    	{
    		return n;
    	}
    	if(n%m==0)
    	{
    		return m;
    	}
    	return gcd(m,n%m);
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter the first Number");
    int n=sc.nextInt();
    System.out.println("Enter the second Number");
    int m=sc.nextInt();
    sc.close();
    System.out.println(gcd(n,m)+" First Method Answer");
    System.out.println(gcdsecondmethod(n,m)+" second method answer");
	}

}
