package Stackproblems;
import java.util.*;
public class reverseaStack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack<Integer> st=new Stack<>();
		st.push(10);
		st.push(20);
		st.push(30);
		st.push(40);
		st.push(50);
		System.out.println(st);
		logic(st);
		System.out.println(st);

	}

	private static void logic(Stack<Integer> st) {
		// TODO Auto-generated method stub
		if(st.empty())
		{
			return;
		}
		int val=st.pop();
		logic(st);
		insertbottom(st,val);
	}

	private static void insertbottom(Stack<Integer> st, int val) {
		// TODO Auto-generated method stub
		if(st.empty())
		{
			st.push(val);
			return;
		}
		int k=st.pop();
		insertbottom(st,val);
		st.push(k);
		
	}

}
