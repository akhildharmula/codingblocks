package Graph;
import java.util.*;
public class prims {
	
		public HashMap<Integer, HashMap<Integer, Integer>> map;
		public prims() {
			this.map = new HashMap<>();
		}
		public void addedge(Integer u, Integer v, int cost) {
			if (map.containsKey(u)) {
				map.get(u).put(v, cost);
			} else {
				map.put(u, new HashMap<>());
				map.get(u).put(v, cost);
			}

			if (map.containsKey(v)) {
				map.get(v).put(u, cost);
			} else {
				map.put(v, new HashMap<>());
				map.get(v).put(u, cost);
			}
		}

		public void display() {
			for (Integer u : map.keySet()) {
				System.out.println(u + "  " + map.get(u));
			}
		}
	

	public class primspair {
		int v1;
		int v2;
		int cost;
		public primspair()
		{
			
		}
		
		public primspair(int v1,int v2,int cost)
		{
			this.v1=v1;
			this.v2=v2;
			this.cost=cost;
		}
		
		public String toString()
		{
			return v1+" "+v2+" "+cost;
		}
	}
	
	public void mst(int start)
	{
		PriorityQueue<primspair> pq=new PriorityQueue<>(new Comparator<primspair>() {

			@Override
			public int compare(primspair o1, primspair o2) {
				
				return o1.cost-o2.cost;
			}
		});
		ArrayList<Integer> visted=new ArrayList<>();
		primspair p=new primspair(start,start,0);
		pq.add(p);
		int ans=0;
		while(!pq.isEmpty())
		{
			primspair pp=pq.remove();
			if(visted.contains(pp.v1))
				continue;
			System.out.println(pp.toString());
			ans+=pp.cost;
			visted.add(pp.v1);
			for(int k:map.get(pp.v1).keySet())
			{
				primspair pair=new primspair(k,pp.v1,map.get(pp.v1).get(k));
				pq.add(pair);
				
			}	
		}
		System.out.println("totalcost "+ans);
		
	}
	
	
}
