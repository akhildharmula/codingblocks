package Graph;
import java.util.*;
public class creategraphusingHashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int n=10;
		 Scanner sc=new Scanner(System.in);
		 HashMap<Integer,HashMap<Integer,Integer>> map =new HashMap<>();
		 for(int i=0;i<n;i++)
		 {
			 int u=sc.nextInt();
			 int v=sc.nextInt();
			 if(map.containsKey(u))
			 {
				 map.get(u).put(v,0);
			 }
			 else
			 {
				 map.put(u,new HashMap<>());
				 map.get(u).put(v,0); 
			 }
		 }
		 
		 for(Integer u: map.keySet())
		 {
			 for(Integer v:map.get(u).keySet())
			 {
				 System.out.println(u+" "+v);
			 }
		 }
		 
		 
		 
		 sc.close();
	}

}
