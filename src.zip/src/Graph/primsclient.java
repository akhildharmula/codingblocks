package Graph;

public class primsclient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		prims p=new prims();
		p.addedge(1, 4, 11);
		p.addedge(1, 2, 2);
		p.addedge(2, 3, 3);
		p.addedge(3, 4, 5);
		p.addedge(4, 5, 8);
		p.addedge(5, 7, 1);
		p.addedge(5, 6, 7);
		p.addedge(6, 7, 9);
		p.mst(1);
		

	}

}
