package Graph;

import java.util.*;

public class graphclient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		graph g = new graph();
		g.addedge(1, 4, 2);
		g.addedge(1, 2, 3);
		g.addedge(2, 3, 9);
		g.addedge(3, 4, 4);
		g.addedge(4, 5, 11);
		g.addedge(5, 6, 6);
		g.addedge(6, 7, 17);
		g.addedge(7, 5, 14);
		g.display();
		System.out.println("no of edges  " + g.noofedges());
		System.out.println(g.haspath(1, 10));
		g.printpaths(1, 6);
		g.bfs(1);
		g.dfs(1);
		System.out.println(g.hasCycle(1));
		g.removeedge(1, 2);
		g.removeedge(5, 7);
		System.out.println(g.hasCycle(1));
		sc.close();

	}

}
