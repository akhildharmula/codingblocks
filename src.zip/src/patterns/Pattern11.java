package patterns;
import java.util.*;
public class Pattern11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner sc=new Scanner(System.in);
   System.out.println("Enter a Number");
   int n=sc.nextInt();
   sc.close();
   int nsp=n-1;
   int nsv=1;
   for(int i=1;i<=n;i++)
   { int value=1;
	   for(int j=0;j<nsp;j++)
	   {
		   System.out.print("  ");
	   }
	   for(int j=1;j<=nsv;j++)
	   {
		   System.out.print(value+" ");
		   if(j<i)
		   {
			   value++;
		   }
		   else
		   {   value--;
			   
		   }
	   }
	   System.out.println();
	   nsp--;
	   nsv=nsv+2;
   }
	}

}
