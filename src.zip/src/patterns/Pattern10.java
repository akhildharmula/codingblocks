package patterns;
import java.util.*;
public class Pattern10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter a Number");
    int n=sc.nextInt();
    sc.close();
    int nsp=n-1;
    int value=1;
    int nsv=1;
    for(int i=0;i<n;i++)
    {   
    
    	for(int j=0;j<nsp;j++)
    	{
    		System.out.print("  ");
    	}
    	for(int j=0;j<nsv;j++)
    	{
    		System.out.print(value+" ");
    		value++;
    	}
    	System.out.println();
    	nsp--;
    	nsv=nsv+2;
    }
	}

}
