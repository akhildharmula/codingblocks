package patterns;
import java.util.*;
public class Pattern3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner sc=new Scanner(System.in);
   System.out.println("Enter the number :");
   int n=sc.nextInt();
   sc.close();
   for(int i=0;i<n;i++)
   {
	   for(int j=0;j<n;j++)
	   {
		   if(j<(n-i)-1)
		   {
			   System.out.print("  ");
		   }
		   else
		   {
			   System.out.print("* ");
		   }
	   }
	   System.out.println();
	   
   }
	}

}
