package patterns;
import java.util.*;
/*     
# 
# # 
# # # 
# # # # 
# # # # # 
# # # # # 
# # # # 
# # # 
# # 
#       
 */

public class Pattern7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter a Number");
     int n=sc.nextInt();
     sc.close();
     for(int i=0;i<2*n;i++)
     {
    	 if(i<n)
    	 {
    	 for(int j=0;j<=i;j++)
    	 {
    		 System.out.print("* ");
    	 }
         }
    	 else
         {
    	 for(int j=0;j<(2*n)-i;j++)
    	 {
    		 System.out.print("* ");
    	 }
         }
    	 System.out.println();
	}
	
	}
}
