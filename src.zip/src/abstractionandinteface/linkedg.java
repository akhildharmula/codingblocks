package abstractionandinteface;


public class linkedg <T> {
	private class Node
	{
		T data;
		Node next;
	}
	Node Head;
	Node Tail;
	int size;
	public  void  insertdataatfirst(T val) {
		Node newnode=new Node();
		newnode.data=val;
		if(size==0)
		{
			Tail=newnode;
		}
		else
		{
			newnode.next=Head;
		}
		Head=newnode;
		size++;
	}
	public void insertdataatlast(T val)
	{
		Node newnode=new Node();
		newnode.data=val;
		if(size!=0)
		{
			Tail.next=newnode;
			Tail=newnode;
			size++;
		}
		else
		{
			insertdataatfirst(val);
		}
	}
	public void insertatindex(T val,int idx)
	{
		if(idx==0)
		{
			insertdataatfirst(val);
		}
		else
		{
			if(idx==size)
			{
				insertdataatlast(val);
			}
			else
			{
				Node newnode=new Node();
				newnode.data=val;
				Node temp=getNode(idx-1);
				Node temp2=temp.next;
				temp.next=newnode;
				newnode.next=temp2;
				size++;
			}
		}
	}
	public Node getNode(int idx)
	{
		Node temp=Head;
		for(int i=1;i<=idx;i++)
		{
			temp=temp.next;
		}
		return temp;
	}
	public T getFirst()throws Exception
	{
		if(size!=0)
		return Head.data;
		throw new Exception("linked list is empty");
	}
	public T getLast() throws Exception
	{
		if(size!=0)
		return Tail.data;
		throw new Exception("Linked list is empty");
	}
	public int size()
	{
		return size;
	}
	public void removeFirst()throws Exception
	{
		if(size!=0)
		{
		   Node temp=Head;
		   Head=Head.next;
		   temp.next=null;
		   size--;
		   return;
		}
		throw new Exception("Linked List is Empty");
		
	}
	public void removeLast()throws Exception
	{
		if(size!=0)
		{
		   Node temp=getNode(size-1);
		   temp.next=null;
		   size--;
		   return;
		}
		throw new Exception("Linked List is Empty");
		
	}
	
	public void removeKthNode(int k)throws Exception
	{
		if(size!=0)
		{
		   Node temp=getNode(k-1);
		   temp.next=temp.next.next;
		   temp.next.next=null;
		   size--;
		   return;
		}
		throw new Exception("Linked List is Empty");
		
	}
	public boolean isempty()
	{
		return size==0;
	}
	public void display()throws Exception
	{
		if(size!=0)
		{
		   Node temp=Head;
		   while(temp!=null)
		   {
			   System.out.print(temp.data+" ");
			   temp=temp.next;
		   }
		   return;
		}
		throw new Exception("Linked List is Empty");
		
	}
	

}
