package abstractionandinteface;

public interface inteface2 {
	public void fun();
	public void fun2();

}
