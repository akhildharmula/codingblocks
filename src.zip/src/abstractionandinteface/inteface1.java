package abstractionandinteface;

public interface inteface1 {
	public void fun();
	public void fun1();

}
