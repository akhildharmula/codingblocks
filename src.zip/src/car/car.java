package car;

public class car {
	int price;
	int speed;
	String color;
	
	public car(int price,int speed,String color)
	{
		this.price=price;
		this.speed=speed;
		this.color=color;	
	}
	public String toString()
	{
		String str=this.price+" "+this.speed+" "+this.color;
		return str;
	}

}
