package TwoDArrays;

import java.util.Scanner;

public class WavePrinting1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the No of Rows");
		int n=sc.nextInt();
		System.out.println("Enter the No of columns");
		int m=sc.nextInt();
		int arr[][]=new int[n][m];
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		Printing1(arr);
		
		sc.close();
		

	}

	private static void Printing1(int[][] arr) {
		// TODO Auto-generated method stub
		int i=0,j=0;
		while(i<arr[0].length)
		{
			if(i%2==0)
			{
				while(j<arr.length)
			    {
			    	System.out.print(arr[j][i]+" ");
			    	j++;
			    }
			    j--;
			}
			else
			{
				while(j>=0)
			    {
			    	System.out.print(arr[j][i]+" ");
			    	j--;
			    }
			    j++;
				
			}
		    
		    i++;
		}
		
	}

}
