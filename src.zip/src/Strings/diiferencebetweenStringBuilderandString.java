package Strings;

public class diiferencebetweenStringBuilderandString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  StringBuilder sb=new StringBuilder();
  String s="";
  double start=System.currentTimeMillis();
  for(int i=0;i<1000000;i++)
  {
	  s=s+i;
  }
  double end=System.currentTimeMillis();
  System.out.println(start-end);
  
  start=System.currentTimeMillis();
  for(int i=0;i<1000000;i++)
  {
	  sb=sb.append(i);
  }
   end=System.currentTimeMillis();
  System.out.println(start-end);
		
	}

}
