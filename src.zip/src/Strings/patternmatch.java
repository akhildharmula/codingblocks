package Strings;

import java.util.*;

public class patternmatch {
	public static boolean hasalacharacters(int start, int end, String s, String p) {
		HashMap<Character, Integer> q = new HashMap<>();
		for (int i = start; i <= end; i++) {
			if (q.containsKey(s.charAt(i))) {
				q.put(s.charAt(i), q.get(s.charAt(i)) + 1);
			} else {
				q.put(s.charAt(i), 1);
			}
		}
		for (int i = 0; i < p.length(); i++) {
			if (q.containsKey(p.charAt(i))) {
				if (q.get(p.charAt(i)) == 0) {
					return false;
				}
				q.put(p.charAt(i), q.get(p.charAt(i)) - 1);
			} else {
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="this is a test string";
		String p="tist";
//		String s = "abcdefghijk";
//		String p = "dj";
		int start = 0;
		int end = p.length();
		String ans = "" + s;
		while (start <= end && end < s.length()) {
			if (hasalacharacters(start, end, s, p)) {
				if (s.substring(start, end + 1).length() < ans.length())
					ans = s.substring(start, end + 1);
				start++;
			} else {
				end++;
			}
		}
		System.out.println(ans);

	}

}
