package Strings;

public class Printallthesubarrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "nitin";
		for (int i = 0; i < s.length(); i++) {
			for (int j = i + 1; j <= s.length(); j++) {
				int k = 0;
				int start = i;
				int end = j - 1;
				while (start <= end) {
					if (s.charAt(start) == s.charAt(end)) {
						start++;
						end--;
					} else {
						k = 1;
						break;
					}

				}
				if (k == 0) {
					System.out.println(s.substring(i, j));
				}
			}
		}

	}

}
