package Strings;

public class asciivaluedifference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="acb";
		String ans="";
		for(int i=0;i<s.length()-1;i++)
		{
			int diff=s.charAt(i+1)-s.charAt(i);
			ans=ans+s.charAt(i)+diff;
		}
		ans=ans+s.charAt(s.length()-1);
		System.out.println(ans);

	}

}
