package Strings;

public class Stringfrequency {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="aaaebbbcccssss";
		String ans="";
		int i=1;
		int count=1;
		while(i<=s.length())
		{
			while(i<s.length() && s.charAt(i-1)==s.charAt(i))
			{
				count++;
				i++;
			}
			ans=ans+s.charAt(i-1);
			if(count!=1)
			{
				ans=ans+count;
			}
			count=1;
			i++;
		}
		System.out.println(ans);

	}

}
