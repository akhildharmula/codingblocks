package backTracking;

public class WordSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[][] box= {{'a','b','c','d'},
				       {'k','h','i','d'},
				       {'a','b','l','d'},
				       {'a','b','c','d'},
				       {'a','b','c','d'}};
		boolean t=false;
		boolean [][] vis=new boolean[box.length][box[0].length];
		for(int i=0;i<box.length;i++)
		{
			for(int j=0;j<box[i].length;j++)
			{
				if(find(box,"khilbbba","",i,j,vis))
				{
					
					System.out.println(true);
					return;
				}
			}
		}
		System.out.println(false);
		
		}

	private static boolean find(char[][] box, String s,String ans,int row,int col,boolean [][] vis) {
		// TODO Auto-generated method stub
		if(s.equals(ans))
		{
			return true;
		}
		if(ans.length()>s.length())
		{
			return false;
		}
		if(row>=box.length || row<0 || col>=box[row].length || col<0)
		{
			return false;
		}
		boolean temp=false;
		if(!temp && vis[row][col]==false)
		{
			vis[row][col]=true;
			temp=find(box,s,ans+box[row][col],row-1,col,vis);
			vis[row][col]=false;
		}
		if(!temp && vis[row][col]==false)
		{
			vis[row][col]=true;
			temp=find(box,s,ans+box[row][col],row,col-1,vis);
			vis[row][col]=false;
		}
		if(!temp && vis[row][col]==false)
		{
			vis[row][col]=true;
			temp=find(box,s,ans+box[row][col],row+1,col,vis);
			vis[row][col]=false;
		}
		if(!temp && vis[row][col]==false)
		{
			vis[row][col]=true;
			temp=find(box,s,ans+box[row][col],row,col+1,vis);
			vis[row][col]=false;
		}
		return temp;
	}
	    
	}


