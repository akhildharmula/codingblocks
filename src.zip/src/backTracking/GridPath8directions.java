package backTracking;

public class GridPath8directions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int vis[][]=new int[4][4];
		printpaths(4,4,0,0,"",vis);

	}

	private static void printpaths(int n, int m, int i, int j, String s, int[] vis) {
		// TODO Auto-generated method stub
		if(i==n-1 &&j==n-1)
		{
			System.out.println(ans);
			return;
		}
		
	}

}
