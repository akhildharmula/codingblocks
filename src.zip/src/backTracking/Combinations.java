package backTracking;
import java.util.*;
public class Combinations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=4;
		int k=2;
		List<Integer> a=new ArrayList<>();
		List<List<Integer>> ans=new ArrayList<>();
		ans=printCombinations(n,k,a,ans,1);
	    System.out.println(ans);
	}

	private static List<List<Integer>> printCombinations(int n, int k, List<Integer> a, List<List<Integer>> ans,
			int start) {
		// TODO Auto-generated method stub
		if(a.size()==k)
		{
			ans.add(new ArrayList<>(a));
			return ans;
		}
		for(int i=start;i<=n;i++)
		{
			a.add(i);
			ans=printCombinations(n,k,a,ans,i+1);
			a.remove(a.size()-1);
		}
		return ans;
	}

}
