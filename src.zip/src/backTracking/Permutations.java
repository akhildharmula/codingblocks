package backTracking;
import java.util.*;
public class Permutations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {1,2,2};
		boolean vis[]=new boolean[arr.length];
		ArrayList<Integer> list=new ArrayList<>();
		print(arr,list,vis);
		
	}
    
	private static void print(int[] arr, ArrayList<Integer> list,boolean[] vis) {
		// TODO Auto-generated method stub
		//System.out.println(list);
		if(list.size()==arr.length)
		{
			System.out.println(list);
			return;
		}
		for(int i=0;i<arr.length;i++)
		{ 
			if(!vis[i] && !search(arr[i],arr,i,vis) )
		   {
			list.add(arr[i]);
			vis[i]=true;
			print(arr,list,vis);
			list.remove(list.size()-1);
			vis[i]=false;
		   }
			
		}
		
	}

	private static boolean search(int target, int[] arr, int start,boolean[] vis) {
		// TODO Auto-generated method stub
		for(int i=start+1;i<arr.length;i++)
		{
			if(arr[i]==target && vis[i]==false)
			{
				return true;
			}
		}
		return false;
		
	}

	

}
