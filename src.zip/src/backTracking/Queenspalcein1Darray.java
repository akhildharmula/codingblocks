package backTracking;

public class Queenspalcein1Darray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub4
		System.out.println(print(2,4,"",-1));

	}

	private static int print(int q, int b, String ans, int in) {
		// TODO Auto-generated method stub
		if(q==0)
		{
			System.out.println(ans);
			return 1;
		}
		int sum=0;
		for(int i=0;i<b;i++)
		{
			if(i!=in)
			sum+=print(q-1,b,ans+"b"+i+"Q"+q,i);
		}
		return sum;

	}

}
