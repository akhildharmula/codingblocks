package linkedlist;

public class test {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
           LinkedList li=new LinkedList();
           System.out.println(li.size());
           li.insertdataatfirst(2);
           li.insertdataatfirst(9);
           li.insertdataatfirst(1);
           li.insertdataatfirst(2);
           li.display();
           System.out.println();
           li.ajayaccenture();
           li.display();
       
           
           
	}

}
