package NumberSystem;
import java.util.*;
public class PascalTraingle {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner sc=new Scanner(System.in);
   int n;
   n=sc.nextInt();
   sc.close();
   int nst=1;
        for(int row=0;row<=n;row++)
        {
        	int ncr=1;
        	for(int j=0;j<nst;j++)
        	{
        		System.out.print(ncr+" ");
        		ncr=((row-j)*ncr)/(j+1);
        	}
        	nst++;
        	System.out.println();
        }
	}

}
