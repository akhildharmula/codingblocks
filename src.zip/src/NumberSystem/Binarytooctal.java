package NumberSystem;

import java.util.Scanner;

public class Binarytooctal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter the Binary Number");
	     int n=sc.nextInt();
	     sc.close();
	     int bi=0;
	     int mul=1;
	     while(n!=0)
	     {
	    	 int rem=n%10;
	    	 n=n/10;
	    	 bi=bi+(mul*rem);
	    	 mul=mul*2;
	     }
	     mul=1;
	     n=0;
	     while(bi!=0)
	     {
	    	 int rem=bi%8;
	    	 bi=bi/8;
	    	 n=n+(mul*rem);
	    	 mul=mul*10;
	     }
	     System.out.println(n);

	}

}
