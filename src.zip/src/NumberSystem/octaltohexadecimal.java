package NumberSystem;
import java.util.*;
public class octaltohexadecimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the octal number");
		int n=sc.nextInt();
		int decimal=ocatltodecimal(n);
		String ans=decimaltohexa(decimal);
		System.out.println(ans);
        sc.close();
	}

	private static String decimaltohexa(int n) {
		// TODO Auto-generated method stub
		String ans="";
		while(n!=0)
		{
			int rem=n%16;
			if(rem<10)
			{
				ans=rem+ans;
			}
			else
			{
				ans=(char)(rem+55)+ans;
			}
			n=n/16;
		}
		return ans;
	}

	private static int ocatltodecimal(int n) {
		// TODO Auto-generated method stub
		int oc=0;
	     int mul=1;
	     while(n!=0)
	     {
	    	 int rem=n%10;
	    	 n=n/10;
	    	 oc=oc+(mul*rem);
	    	 mul=mul*8;
	     }
		return oc;
	}

}
