package NumberSystem;
import java.util.*;
public class octaltobinary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter the octal Number");
	     int n=sc.nextInt();
	     sc.close();
	     int oc=0;
	     int mul=1;
	     while(n!=0)
	     {
	    	 int rem=n%10;
	    	 n=n/10;
	    	 oc=oc+(mul*rem);
	    	 mul=mul*8;
	     }
	     mul=1;
	     n=0;
	     while(oc!=0)
	     {
	    	 int rem=oc%2;
	    	 oc=oc/2;
	    	 n=n+(mul*rem);
	    	 mul=mul*10;
	     }
	     System.out.println(n);

	}

}
