package NumberSystem;
import java.util.*;
public class hexatooctal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String hecdec=sc.nextLine();
		int decimal=hexatodecimal(hecdec);
		int octal=decimaltooctal(decimal);
		System.out.println(octal);
		sc.close();

	}

	private static int decimaltooctal(int n) {
		// TODO Auto-generated method stub
		int oc=0;
	     int mul=1;
	     while(n!=0)
	     {
	    	 int rem=n%8;
	    	 oc=oc+(mul*rem);
	    	 mul=mul*10;
	    	 n=n/8;
	     }
		return oc;
	}

	private static int hexatodecimal(String hecdec) {
		// TODO Auto-generated method stub
		String s="0123456789ABCDEF";
		hecdec.toUpperCase();
		int val=0;
		for(int i=0;i<hecdec.length();i++)
		{
			char ch=hecdec.charAt(i);
			int d=s.indexOf(ch);
           val=val*16+d;
		}
		return val;
	}

}
