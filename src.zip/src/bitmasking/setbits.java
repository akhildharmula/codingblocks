package bitmasking;

public class setbits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=9;
		int c=0;
		while(n!=0)
		{
			if((n&1)!=0)
			{
				c++;
			}
			n>>=1;
		}
		System.out.println(c);

	}

}
