package bitmasking;

public class evenandoddusingbits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=17;
		if((n&1)==0)
		{
			System.out.println("even");
		}
		else
		{
			System.out.println("odd");
		}

	}

}
