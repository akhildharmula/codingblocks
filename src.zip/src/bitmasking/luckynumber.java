package bitmasking;

public class luckynumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="4";
		int count=1;
		int pos=0;
		for(int i=s.length()-1;i>=0;i--)
		{
			if(s.charAt(i)=='7')
			{
				count+=1<<pos;
			}
			pos++;
		}
		count+=1<<s.length();
		System.out.println(count-2);
		

	}

}
